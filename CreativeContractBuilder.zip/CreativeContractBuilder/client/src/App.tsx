import { Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import GameStudio from "./components/GameStudio";
import "@fontsource/inter";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <Suspense fallback={
          <div className="flex items-center justify-center min-h-screen">
            <div className="text-white text-xl">Loading Game Studio...</div>
          </div>
        }>
          <GameStudio />
        </Suspense>
      </div>
    </QueryClientProvider>
  );
}

export default App;
