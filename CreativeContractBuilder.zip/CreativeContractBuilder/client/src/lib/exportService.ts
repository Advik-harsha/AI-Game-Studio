export interface ExportConfig {
  gameName: string;
  description: string;
  author: string;
  version: string;
  includeSource: boolean;
}

export async function exportGame(
  templateId: string,
  gameData: any,
  config: ExportConfig
): Promise<Blob> {
  try {
    const response = await fetch('/api/export/game', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        templateId,
        gameData,
        config,
      }),
    });

    if (!response.ok) {
      throw new Error(`Export failed: ${response.status}`);
    }

    return await response.blob();
  } catch (error) {
    console.error('Error exporting game:', error);
    throw new Error('Failed to export game. Please try again.');
  }
}
