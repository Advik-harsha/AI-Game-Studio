import { create } from "zustand";

export type GameStudioStep = 'template' | 'customize' | 'parameters' | 'export';

interface GameData {
  customization: {
    theme?: string;
    environment?: string;
    mainCharacter?: string;
    obstacles?: string;
    themeGenerated?: any;
    environmentGenerated?: any;
    mainCharacterGenerated?: any;
    obstaclesGenerated?: any;
  };
  parameters: {
    difficulty?: string;
    musicStyle?: string;
    enableCoins?: boolean;
    coinValue?: number;
    [key: string]: any;
  };
}

interface GameStudioState {
  currentStep: GameStudioStep;
  selectedTemplate: string | null;
  gameData: GameData;
  
  // Actions
  setCurrentStep: (step: GameStudioStep) => void;
  setSelectedTemplate: (template: string) => void;
  updateGameData: (data: Partial<GameData>) => void;
  resetGameData: () => void;
}

const initialGameData: GameData = {
  customization: {},
  parameters: {}
};

export const useGameStudio = create<GameStudioState>((set) => ({
  currentStep: 'template',
  selectedTemplate: null,
  gameData: initialGameData,
  
  setCurrentStep: (step) => set({ currentStep: step }),
  
  setSelectedTemplate: (template) => set({ 
    selectedTemplate: template,
    currentStep: 'customize'
  }),
  
  updateGameData: (data) => set((state) => ({
    gameData: {
      customization: { ...state.gameData.customization, ...data.customization },
      parameters: { ...state.gameData.parameters, ...data.parameters }
    }
  })),
  
  resetGameData: () => set({ gameData: initialGameData })
}));
