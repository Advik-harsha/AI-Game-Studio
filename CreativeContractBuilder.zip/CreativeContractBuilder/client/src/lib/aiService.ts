export interface AIGenerationResponse {
  assets?: {
    images?: string[];
    colors?: string[];
    descriptions?: string[];
  };
  success: boolean;
  message?: string;
}

export interface GameParametersResponse {
  parameters: Record<string, number>;
  success: boolean;
  message?: string;
}

export async function generateGameAssets(
  gameTemplate: string,
  aspect: string,
  prompt: string
): Promise<AIGenerationResponse> {
  try {
    const response = await fetch('/api/ai/generate-assets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        gameTemplate,
        aspect,
        prompt,
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error generating assets:', error);
    return {
      success: false,
      message: 'Failed to generate assets. Please try again.',
    };
  }
}

export async function generateGameParameters(
  gameTemplate: string,
  prompt: string,
  difficulty: string
): Promise<GameParametersResponse> {
  try {
    const response = await fetch('/api/ai/generate-parameters', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        gameTemplate,
        prompt,
        difficulty,
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error generating parameters:', error);
    return {
      success: false,
      message: 'Failed to generate parameters. Please try again.',
      parameters: {},
    };
  }
}
