import { useState } from "react";
import { useGameStudio } from "@/lib/stores/useGameStudio";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Download, Package, Share, CheckCircle } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { exportGame } from "@/lib/exportService";

export default function ExportManager() {
  const { selectedTemplate, gameData } = useGameStudio();
  const [exportConfig, setExportConfig] = useState({
    gameName: `My Custom ${selectedTemplate?.replace('-', ' ').toUpperCase()} Game`,
    description: 'Created with AI Game Studio',
    author: '',
    version: '1.0.0',
    includeSource: false
  });

  const exportMutation = useMutation({
    mutationFn: () => exportGame(selectedTemplate!, gameData, exportConfig),
    onSuccess: (blob) => {
      // Create download link
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${exportConfig.gameName.replace(/\s+/g, '-').toLowerCase()}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  });

  const handleExport = () => {
    exportMutation.mutate();
  };

  const gameFeatures = [
    'Fully playable HTML5 game',
    'Mobile-friendly touch controls',
    'Offline gameplay capability',
    'Custom AI-generated assets',
    'Optimized performance',
    'Cross-browser compatibility'
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold text-white mb-6">Export Your Game</h2>
      <p className="text-gray-300 mb-8">
        Your game is ready! Configure the export settings and download your custom HTML5 game.
      </p>

      <div className="space-y-6">
        {/* Game Summary */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Package className="w-5 h-5" />
              <span>Game Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-gray-400 text-sm">Template:</span>
                <p className="text-white font-medium">
                  {selectedTemplate?.replace('-', ' ').toUpperCase()}
                </p>
              </div>
              <div>
                <span className="text-gray-400 text-sm">Difficulty:</span>
                <p className="text-white font-medium">
                  {gameData.parameters.difficulty || 'Medium'}
                </p>
              </div>
            </div>

            <div>
              <span className="text-gray-400 text-sm">Customizations Applied:</span>
              <div className="flex flex-wrap gap-2 mt-2">
                {Object.entries(gameData.customization).map(([key, value]) => 
                  value ? (
                    <Badge key={key} variant="secondary">
                      {key.charAt(0).toUpperCase() + key.slice(1)}
                    </Badge>
                  ) : null
                )}
              </div>
            </div>

            <div>
              <span className="text-gray-400 text-sm">Features:</span>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {gameFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-sm text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Export Configuration */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Export Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-gray-300">Game Name</Label>
                <Input
                  value={exportConfig.gameName}
                  onChange={(e) => setExportConfig(prev => ({ ...prev, gameName: e.target.value }))}
                  className="bg-white/5 border-white/20 text-white"
                  placeholder="Enter game name"
                />
              </div>
              <div>
                <Label className="text-gray-300">Author</Label>
                <Input
                  value={exportConfig.author}
                  onChange={(e) => setExportConfig(prev => ({ ...prev, author: e.target.value }))}
                  className="bg-white/5 border-white/20 text-white"
                  placeholder="Your name"
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-300">Description</Label>
              <Textarea
                value={exportConfig.description}
                onChange={(e) => setExportConfig(prev => ({ ...prev, description: e.target.value }))}
                className="bg-white/5 border-white/20 text-white"
                placeholder="Describe your game"
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="includeSource"
                checked={exportConfig.includeSource}
                onChange={(e) => setExportConfig(prev => ({ ...prev, includeSource: e.target.checked }))}
                className="rounded"
              />
              <Label htmlFor="includeSource" className="text-gray-300">
                Include source code (for developers)
              </Label>
            </div>
          </CardContent>
        </Card>

        {/* Export Actions */}
        <Card className="bg-gradient-to-r from-green-500/20 to-blue-500/20 border-green-500/30">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <h3 className="text-xl font-semibold text-white">Ready to Export!</h3>
              <p className="text-gray-300">
                Your game will be packaged as a ZIP file containing all necessary files 
                to run offline in any modern web browser.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleExport}
                  disabled={exportMutation.isPending}
                  size="lg"
                  className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold px-8"
                >
                  {exportMutation.isPending ? (
                    <>
                      <Package className="w-5 h-5 mr-2 animate-spin" />
                      Packaging...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5 mr-2" />
                      Download Game
                    </>
                  )}
                </Button>

                <Button
                  variant="outline"
                  size="lg"
                  className="border-white/30 text-white hover:bg-white/10"
                  onClick={() => {
                    // Future: implement sharing feature
                    alert('Sharing feature coming soon!');
                  }}
                >
                  <Share className="w-5 h-5 mr-2" />
                  Share Game
                </Button>
              </div>

              {exportMutation.isSuccess && (
                <div className="p-4 bg-green-500/20 border border-green-500/30 rounded-lg">
                  <p className="text-green-300 font-medium">
                    🎉 Game exported successfully! Check your downloads folder.
                  </p>
                </div>
              )}

              {exportMutation.isError && (
                <div className="p-4 bg-red-500/20 border border-red-500/30 rounded-lg">
                  <p className="text-red-300">
                    Export failed. Please try again or contact support.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card className="bg-white/5 border-white/10">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-white mb-4">How to use your exported game:</h3>
            <ol className="space-y-2 text-gray-300">
              <li>1. Extract the ZIP file to a folder on your computer</li>
              <li>2. Open the <code className="bg-gray-800 px-1 rounded">index.html</code> file in any web browser</li>
              <li>3. Your game will start automatically and work offline</li>
              <li>4. Share the folder with others or upload to a web server</li>
            </ol>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
