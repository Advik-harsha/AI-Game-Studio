import { useState } from "react";
import { useGameStudio } from "@/lib/stores/useGameStudio";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Loader2, Sparkles, Wand2 } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { generateGameAssets } from "@/lib/aiService";

const customizationAspects = [
  {
    id: 'theme',
    title: 'Story/Theme/Art Style',
    placeholder: 'e.g., Medieval fantasy, Space adventure, Underwater world...',
    examples: ['Cyberpunk city', 'Magical forest', 'Retro arcade', 'Steampunk world']
  },
  {
    id: 'environment',
    title: 'Environment/Background',
    placeholder: 'e.g., Dark cave, Sunny beach, Neon city, Ancient temple...',
    examples: ['Floating islands', 'Desert oasis', 'Space station', 'Haunted mansion']
  },
  {
    id: 'mainCharacter',
    title: 'Main Character',
    placeholder: 'e.g., Robot ninja, Cute cat, Brave knight, Alien explorer...',
    examples: ['Flying dragon', 'Pixel warrior', 'Magic wizard', 'Space pilot']
  },
  {
    id: 'obstacles',
    title: 'Obstacles/Enemies',
    placeholder: 'e.g., Spinning blades, Ghost spirits, Laser barriers...',
    examples: ['Fire traps', 'Ice monsters', 'Moving platforms', 'Energy shields']
  }
];

export default function AICustomizer() {
  const { selectedTemplate, gameData, updateGameData } = useGameStudio();
  const [prompts, setPrompts] = useState(gameData.customization);
  const [generatingAspect, setGeneratingAspect] = useState<string | null>(null);

  const generateAssetsMutation = useMutation({
    mutationFn: ({ aspect, prompt }: { aspect: string; prompt: string }) =>
      generateGameAssets(selectedTemplate!, aspect, prompt),
    onSuccess: (data, variables) => {
      updateGameData({
        customization: {
          ...gameData.customization,
          [variables.aspect]: variables.prompt,
          [`${variables.aspect}Generated`]: data
        }
      });
      setGeneratingAspect(null);
    },
    onError: () => {
      setGeneratingAspect(null);
    }
  });

  const handleGenerate = async (aspect: string) => {
    const prompt = prompts[aspect];
    if (!prompt?.trim()) return;

    setGeneratingAspect(aspect);
    generateAssetsMutation.mutate({ aspect, prompt });
  };

  const handlePromptChange = (aspect: string, value: string) => {
    setPrompts(prev => ({ ...prev, [aspect]: value }));
    updateGameData({
      customization: { ...gameData.customization, [aspect]: value }
    });
  };

  const useExample = (aspect: string, example: string) => {
    handlePromptChange(aspect, example);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-white mb-6">AI-Powered Customization</h2>
      <p className="text-gray-300 mb-8">
        Describe what you want and let AI generate custom visuals for your game. 
        Be creative with your descriptions!
      </p>

      <div className="space-y-6">
        {customizationAspects.map((aspect) => (
          <Card key={aspect.id} className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Wand2 className="w-5 h-5" />
                <span>{aspect.title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor={aspect.id} className="text-gray-300">
                  Describe your vision
                </Label>
                <Textarea
                  id={aspect.id}
                  placeholder={aspect.placeholder}
                  value={prompts[aspect.id] || ''}
                  onChange={(e) => handlePromptChange(aspect.id, e.target.value)}
                  className="mt-2 bg-white/5 border-white/20 text-white placeholder-gray-400"
                  rows={3}
                />
              </div>

              <div>
                <Label className="text-gray-300 text-sm">Quick examples:</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {aspect.examples.map((example, index) => (
                    <Badge
                      key={index}
                      variant="outline"
                      className="cursor-pointer hover:bg-white/20 text-gray-300 border-gray-500"
                      onClick={() => useExample(aspect.id, example)}
                    >
                      {example}
                    </Badge>
                  ))}
                </div>
              </div>

              <Button
                onClick={() => handleGenerate(aspect.id)}
                disabled={!prompts[aspect.id]?.trim() || generatingAspect === aspect.id}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                {generatingAspect === aspect.id ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate {aspect.title}
                  </>
                )}
              </Button>

              {gameData.customization[`${aspect.id}Generated`] && (
                <div className="p-4 bg-green-500/20 border border-green-500/30 rounded-lg">
                  <p className="text-green-300 text-sm">
                    ✓ Generated! Your custom {aspect.title.toLowerCase()} will be applied to the game.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {Object.values(gameData.customization).some(v => v) && (
        <Card className="mt-6 bg-blue-500/20 border-blue-500/30">
          <CardContent className="p-4">
            <h3 className="text-blue-300 font-semibold mb-2">AI Customization Progress</h3>
            <div className="grid grid-cols-2 gap-4">
              {customizationAspects.map((aspect) => (
                <div key={aspect.id} className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${
                    gameData.customization[aspect.id] ? 'bg-green-400' : 'bg-gray-500'
                  }`} />
                  <span className="text-sm text-gray-300">{aspect.title}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
