import { useEffect, useRef } from "react";
import { useGameStudio } from "@/lib/stores/useGameStudio";
import FlappyBird from "@/games/FlappyBird";
import SpeedRunner from "@/games/SpeedRunner";
import WhackTheMole from "@/games/WhackTheMole";
import Match3 from "@/games/Match3";
import CrossyRoad from "@/games/CrossyRoad";

const gameComponents = {
  'flappy-bird': FlappyBird,
  'speed-runner': SpeedRunner,
  'whack-the-mole': WhackTheMole,
  'match3': Match3,
  'crossy-road': CrossyRoad
};

export default function GamePreview() {
  const { selectedTemplate, gameData } = useGameStudio();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameInstanceRef = useRef<any>(null);

  useEffect(() => {
    if (!selectedTemplate || !canvasRef.current) return;

    const GameComponent = gameComponents[selectedTemplate as keyof typeof gameComponents];
    if (!GameComponent) return;

    // Clean up previous game instance
    if (gameInstanceRef.current?.destroy) {
      gameInstanceRef.current.destroy();
    }

    // Initialize new game instance
    gameInstanceRef.current = new GameComponent(canvasRef.current, {
      customization: gameData.customization,
      parameters: gameData.parameters,
      previewMode: true
    });

    // Start the game
    gameInstanceRef.current.start();

    return () => {
      if (gameInstanceRef.current?.destroy) {
        gameInstanceRef.current.destroy();
      }
    };
  }, [selectedTemplate, gameData]);

  if (!selectedTemplate) {
    return (
      <div className="w-full h-64 bg-gray-800 rounded-lg flex items-center justify-center">
        <p className="text-gray-400">Select a template to see preview</p>
      </div>
    );
  }

  return (
    <div className="w-full">
      <canvas
        ref={canvasRef}
        className="w-full h-64 bg-black rounded-lg border border-gray-600"
        style={{ touchAction: 'none' }}
      />
      <div className="mt-2 text-center">
        <p className="text-xs text-gray-400">
          Preview Mode - Click to interact
        </p>
      </div>
    </div>
  );
}
