import { useState, useRef, useEffect } from "react";
import { useGameStudio } from "@/lib/stores/useGameStudio";
import TemplateSelector from "./TemplateSelector";
import AICustomizer from "./AICustomizer";
import ParameterEditor from "./ParameterEditor";
import GamePreview from "./GamePreview";
import ExportManager from "./ExportManager";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ArrowLeft, ArrowRight, ChevronUp, ChevronDown } from "lucide-react";

const steps = [
  { id: 'template', title: 'Pick Template', component: TemplateSelector },
  { id: 'customize', title: 'AI Reskin', component: AICustomizer },
  { id: 'parameters', title: 'Set Parameters', component: ParameterEditor },
  { id: 'export', title: 'Export Game', component: ExportManager },
];

export default function GameStudio() {
  const { currentStep, setCurrentStep, selectedTemplate, gameData } = useGameStudio();
  const [previewVisible, setPreviewVisible] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const [maxScroll, setMaxScroll] = useState(0);

  const currentStepIndex = steps.findIndex(step => step.id === currentStep);
  const CurrentComponent = steps[currentStepIndex]?.component;

  const canProceed = () => {
    switch (currentStep) {
      case 'template':
        return !!selectedTemplate;
      case 'customize':
        return gameData.customization.theme && gameData.customization.mainCharacter;
      case 'parameters':
        return true; // Parameters are optional
      case 'export':
        return true;
      default:
        return false;
    }
  };

  const nextStep = () => {
    if (currentStepIndex < steps.length - 1 && canProceed()) {
      setCurrentStep(steps[currentStepIndex + 1].id);
    }
  };

  const prevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStep(steps[currentStepIndex - 1].id);
    }
  };

  // Update scroll handler
  useEffect(() => {
    const handleScroll = () => {
      if (containerRef.current) {
        const scrollTop = containerRef.current.scrollTop;
        const scrollHeight = containerRef.current.scrollHeight;
        const clientHeight = containerRef.current.clientHeight;
        const maxScrollValue = scrollHeight - clientHeight;
        
        setScrollPosition(scrollTop);
        setMaxScroll(maxScrollValue);
      }
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
      // Calculate initial max scroll
      handleScroll();
      
      return () => container.removeEventListener('scroll', handleScroll);
    }
  }, [currentStep, previewVisible]);

  const handleSliderChange = (value: number[]) => {
    if (containerRef.current) {
      containerRef.current.scrollTop = value[0];
      setScrollPosition(value[0]);
    }
  };

  const scrollUp = () => {
    if (containerRef.current) {
      containerRef.current.scrollBy({ top: -200, behavior: 'smooth' });
    }
  };

  const scrollDown = () => {
    if (containerRef.current) {
      containerRef.current.scrollBy({ top: 200, behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen p-4 relative">
      {/* Scroll Navigation Controls */}
      {maxScroll > 0 && (
        <div className="fixed right-6 top-1/2 transform -translate-y-1/2 z-50 flex flex-col items-center bg-black/30 backdrop-blur-sm rounded-lg p-3 space-y-2">
          <Button
            onClick={scrollUp}
            size="sm"
            variant="ghost"
            className="text-white hover:bg-white/20 p-2"
            disabled={scrollPosition <= 0}
          >
            <ChevronUp className="w-4 h-4" />
          </Button>
          
          <div className="h-32 py-2">
            <Slider
              value={[scrollPosition]}
              onValueChange={handleSliderChange}
              max={maxScroll}
              min={0}
              step={10}
              orientation="vertical"
              className="h-full"
            />
          </div>
          
          <Button
            onClick={scrollDown}
            size="sm"
            variant="ghost"
            className="text-white hover:bg-white/20 p-2"
            disabled={scrollPosition >= maxScroll}
          >
            <ChevronDown className="w-4 h-4" />
          </Button>
          
          <div className="text-xs text-gray-400 text-center mt-2">
            <div>{Math.round((scrollPosition / maxScroll) * 100)}%</div>
          </div>
        </div>
      )}

      {/* Scrollable Container */}
      <div 
        ref={containerRef}
        className="h-screen overflow-y-auto scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent"
      >
        {/* Header */}
        <div className="max-w-7xl mx-auto mb-8">
        <h1 className="text-4xl font-bold text-white text-center mb-4">
          AI Game Studio
        </h1>
        <p className="text-xl text-gray-300 text-center mb-8">
          Create your own customized HTML5 games with AI assistance
        </p>

        {/* Progress Steps */}
        <div className="flex justify-center mb-8">
          <div className="flex space-x-4">
            {steps.map((step, index) => (
              <div
                key={step.id}
                className={`flex items-center ${
                  index < steps.length - 1 ? 'flex-1' : ''
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                    index <= currentStepIndex
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-600 text-gray-400'
                  }`}
                >
                  {index + 1}
                </div>
                <span
                  className={`ml-2 font-medium ${
                    index <= currentStepIndex ? 'text-white' : 'text-gray-400'
                  }`}
                >
                  {step.title}
                </span>
                {index < steps.length - 1 && (
                  <div
                    className={`flex-1 h-1 mx-4 ${
                      index < currentStepIndex ? 'bg-blue-500' : 'bg-gray-600'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Panel */}
          <div className="lg:col-span-2">
            <Card className="p-6 bg-white/10 backdrop-blur-sm border-white/20">
              {CurrentComponent && <CurrentComponent />}
              
              {/* Navigation */}
              <div className="flex justify-between mt-8">
                <Button
                  onClick={prevStep}
                  disabled={currentStepIndex === 0}
                  variant="outline"
                  className="flex items-center space-x-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Previous</span>
                </Button>

                <div className="flex space-x-4">
                  {selectedTemplate && (
                    <Button
                      onClick={() => setPreviewVisible(!previewVisible)}
                      variant="secondary"
                    >
                      {previewVisible ? 'Hide' : 'Show'} Preview
                    </Button>
                  )}

                  <Button
                    onClick={nextStep}
                    disabled={!canProceed() || currentStepIndex === steps.length - 1}
                    className="flex items-center space-x-2"
                  >
                    <span>Next</span>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Preview Panel */}
          <div className="lg:col-span-1">
            {(selectedTemplate && previewVisible) && (
              <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
                <h3 className="text-lg font-semibold text-white mb-4">Live Preview</h3>
                <GamePreview />
              </Card>
            )}
          </div>
        </div>
        </div>
      </div>
    </div>
  );
}
