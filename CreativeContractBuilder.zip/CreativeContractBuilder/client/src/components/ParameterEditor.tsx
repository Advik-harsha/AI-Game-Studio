import { useState } from "react";
import { useGameStudio } from "@/lib/stores/useGameStudio";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Settings, Zap, Volume2, Coins } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { generateGameParameters } from "@/lib/aiService";

const difficultyPresets = {
  easy: { name: 'Easy', color: 'bg-green-500', description: 'Relaxed gameplay for casual players' },
  medium: { name: 'Medium', color: 'bg-yellow-500', description: 'Balanced challenge for most players' },
  hard: { name: 'Hard', color: 'bg-red-500', description: 'Intense challenge for skilled players' }
};

const gameParameters = {
  'flappy-bird': [
    { key: 'gravity', label: 'Gravity', min: 0.1, max: 2, step: 0.1, unit: '' },
    { key: 'jumpForce', label: 'Jump Force', min: 5, max: 20, step: 1, unit: '' },
    { key: 'pipeGap', label: 'Pipe Gap', min: 100, max: 300, step: 10, unit: 'px' },
    { key: 'pipeSpeed', label: 'Pipe Speed', min: 1, max: 10, step: 0.5, unit: 'px/frame' }
  ],
  'speed-runner': [
    { key: 'runSpeed', label: 'Run Speed', min: 2, max: 15, step: 0.5, unit: 'px/frame' },
    { key: 'jumpHeight', label: 'Jump Height', min: 50, max: 200, step: 10, unit: 'px' },
    { key: 'obstacleFreq', label: 'Obstacle Frequency', min: 0.5, max: 5, step: 0.1, unit: 'per second' },
    { key: 'speedIncrease', label: 'Speed Increase', min: 0.01, max: 0.1, step: 0.01, unit: 'per second' }
  ],
  'whack-the-mole': [
    { key: 'moleSpeed', label: 'Mole Speed', min: 0.5, max: 3, step: 0.1, unit: 'seconds' },
    { key: 'moleCount', label: 'Max Moles', min: 1, max: 6, step: 1, unit: '' },
    { key: 'gameTime', label: 'Game Duration', min: 30, max: 180, step: 15, unit: 'seconds' },
    { key: 'bonusChance', label: 'Bonus Mole Chance', min: 0, max: 30, step: 5, unit: '%' }
  ],
  'match3': [
    { key: 'gridSize', label: 'Grid Size', min: 6, max: 10, step: 1, unit: 'x' },
    { key: 'matchReq', label: 'Match Requirement', min: 3, max: 5, step: 1, unit: 'pieces' },
    { key: 'moveLimit', label: 'Moves per Level', min: 10, max: 50, step: 5, unit: '' },
    { key: 'colorCount', label: 'Color Varieties', min: 4, max: 8, step: 1, unit: '' }
  ],
  'crossy-road': [
    { key: 'laneWidth', label: 'Lane Width', min: 30, max: 80, step: 5, unit: 'px' },
    { key: 'carSpeed', label: 'Traffic Speed', min: 1, max: 8, step: 0.5, unit: 'px/frame' },
    { key: 'carDensity', label: 'Traffic Density', min: 0.1, max: 0.8, step: 0.1, unit: '' },
    { key: 'riverSpeed', label: 'River Current', min: 0.5, max: 4, step: 0.5, unit: 'px/frame' }
  ]
};

export default function ParameterEditor() {
  const { selectedTemplate, gameData, updateGameData } = useGameStudio();
  const [aiPrompt, setAiPrompt] = useState('');
  const [difficulty, setDifficulty] = useState(gameData.parameters.difficulty || 'medium');

  const templateParams = gameParameters[selectedTemplate as keyof typeof gameParameters] || [];

  const generateParamsMutation = useMutation({
    mutationFn: (prompt: string) => generateGameParameters(selectedTemplate!, prompt, difficulty),
    onSuccess: (data) => {
      updateGameData({
        parameters: { ...gameData.parameters, ...data }
      });
    }
  });

  const handleDifficultyChange = (newDifficulty: string) => {
    setDifficulty(newDifficulty);
    updateGameData({
      parameters: { ...gameData.parameters, difficulty: newDifficulty }
    });
  };

  const handleParameterChange = (key: string, value: number) => {
    updateGameData({
      parameters: { ...gameData.parameters, [key]: value }
    });
  };

  const handleAIGenerate = () => {
    if (aiPrompt.trim()) {
      generateParamsMutation.mutate(aiPrompt);
    }
  };

  const resetToDefaults = () => {
    const defaults = templateParams.reduce((acc, param) => {
      acc[param.key] = (param.min + param.max) / 2;
      return acc;
    }, {} as Record<string, number>);

    updateGameData({
      parameters: { ...defaults, difficulty }
    });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-white mb-6">Game Parameters</h2>
      <p className="text-gray-300 mb-8">
        Fine-tune your game's behavior and difficulty. Use AI assistance or adjust manually.
      </p>

      <div className="space-y-6">
        {/* AI Parameter Generation */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Zap className="w-5 h-5" />
              <span>AI Parameter Tuning</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">
                Describe how you want the game to feel
              </Label>
              <Textarea
                placeholder="e.g., Make it more challenging with faster obstacles, or make it more relaxing with slower pace..."
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                className="mt-2 bg-white/5 border-white/20 text-white placeholder-gray-400"
                rows={3}
              />
            </div>
            <Button
              onClick={handleAIGenerate}
              disabled={!aiPrompt.trim() || generateParamsMutation.isPending}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
            >
              {generateParamsMutation.isPending ? 'Generating...' : 'Generate Parameters with AI'}
            </Button>
          </CardContent>
        </Card>

        {/* Difficulty Preset */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Settings className="w-5 h-5" />
              <span>Difficulty Level</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              {Object.entries(difficultyPresets).map(([key, preset]) => (
                <div
                  key={key}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    difficulty === key
                      ? 'border-white bg-white/20'
                      : 'border-gray-500 hover:border-gray-400'
                  }`}
                  onClick={() => handleDifficultyChange(key)}
                >
                  <div className={`w-4 h-4 rounded-full ${preset.color} mb-2`} />
                  <h4 className="font-semibold text-white">{preset.name}</h4>
                  <p className="text-sm text-gray-300 mt-1">{preset.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Manual Parameters */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Manual Adjustments</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {templateParams.map((param) => (
              <div key={param.key}>
                <div className="flex justify-between items-center mb-2">
                  <Label className="text-gray-300">{param.label}</Label>
                  <span className="text-white">
                    {gameData.parameters[param.key] || param.min}{param.unit}
                  </span>
                </div>
                <Slider
                  value={[gameData.parameters[param.key] || param.min]}
                  onValueChange={([value]) => handleParameterChange(param.key, value)}
                  min={param.min}
                  max={param.max}
                  step={param.step}
                  className="w-full"
                />
              </div>
            ))}

            <div className="flex space-x-4 mt-6">
              <Button onClick={resetToDefaults} variant="outline" className="flex-1">
                Reset to Defaults
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Additional Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Volume2 className="w-5 h-5" />
                <span>Audio Settings</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">Background Music Style</Label>
                <Select
                  value={gameData.parameters.musicStyle || 'upbeat'}
                  onValueChange={(value) => updateGameData({
                    parameters: { ...gameData.parameters, musicStyle: value }
                  })}
                >
                  <SelectTrigger className="bg-white/5 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="upbeat">Upbeat & Energetic</SelectItem>
                    <SelectItem value="ambient">Ambient & Calm</SelectItem>
                    <SelectItem value="retro">Retro Chiptune</SelectItem>
                    <SelectItem value="epic">Epic & Dramatic</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Coins className="w-5 h-5" />
                <span>Economy (Optional)</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="enableCoins"
                  checked={gameData.parameters.enableCoins || false}
                  onChange={(e) => updateGameData({
                    parameters: { ...gameData.parameters, enableCoins: e.target.checked }
                  })}
                  className="rounded"
                />
                <Label htmlFor="enableCoins" className="text-gray-300">
                  Enable coin collection system
                </Label>
              </div>
              {gameData.parameters.enableCoins && (
                <div>
                  <Label className="text-gray-300">Coin Value</Label>
                  <Input
                    type="number"
                    value={gameData.parameters.coinValue || 10}
                    onChange={(e) => updateGameData({
                      parameters: { ...gameData.parameters, coinValue: parseInt(e.target.value) }
                    })}
                    className="bg-white/5 border-white/20 text-white"
                    min="1"
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
