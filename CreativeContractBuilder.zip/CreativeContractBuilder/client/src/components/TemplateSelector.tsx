import { useGameStudio } from "@/lib/stores/useGameStudio";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const gameTemplates = [
  {
    id: 'flappy-bird',
    name: 'Flappy Bird',
    description: 'Navigate through pipes by tapping to flap wings',
    difficulty: 'Easy',
    controls: 'Tap/Space',
    features: ['Physics-based flight', 'Pipe obstacles', 'Score system'],
    color: 'from-yellow-400 to-orange-500'
  },
  {
    id: 'speed-runner',
    name: 'Speed Runner',
    description: 'Run and jump through obstacles at increasing speed',
    difficulty: 'Medium',
    controls: 'Arrow Keys/Touch',
    features: ['Side-scrolling action', 'Jump mechanics', 'Speed progression'],
    color: 'from-red-400 to-pink-500'
  },
  {
    id: 'whack-the-mole',
    name: 'Whack the Mole',
    description: 'Quick reflexes game - hit the moles as they appear',
    difficulty: 'Easy',
    controls: 'Click/Tap',
    features: ['Reaction time challenge', 'Multiple targets', 'Timer system'],
    color: 'from-green-400 to-emerald-500'
  },
  {
    id: 'match3',
    name: 'Simple Match-3',
    description: 'Match 3 or more identical items to clear them',
    difficulty: 'Medium',
    controls: 'Drag/Swipe',
    features: ['Grid-based puzzles', 'Combo system', 'Progressive difficulty'],
    color: 'from-purple-400 to-violet-500'
  },
  {
    id: 'crossy-road',
    name: 'Crossy Road',
    description: 'Cross busy roads and rivers without getting hit',
    difficulty: 'Hard',
    controls: 'Swipe/WASD',
    features: ['Isometric view', 'Moving obstacles', 'Endless gameplay'],
    color: 'from-blue-400 to-cyan-500'
  }
];

export default function TemplateSelector() {
  const { selectedTemplate, setSelectedTemplate } = useGameStudio();

  return (
    <div>
      <h2 className="text-2xl font-bold text-white mb-6">Choose Your Game Template</h2>
      <p className="text-gray-300 mb-8">
        Select from our collection of classic game templates. Each template comes with 
        pre-built gameplay mechanics that you can customize with AI.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {gameTemplates.map((template) => (
          <Card
            key={template.id}
            className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
              selectedTemplate === template.id
                ? 'ring-4 ring-blue-400 bg-white/20'
                : 'bg-white/10 hover:bg-white/15'
            } backdrop-blur-sm border-white/20`}
            onClick={() => setSelectedTemplate(template.id)}
          >
            <CardContent className="p-6">
              <div className={`w-full h-32 rounded-lg bg-gradient-to-br ${template.color} mb-4 flex items-center justify-center`}>
                <span className="text-white text-2xl font-bold">{template.name}</span>
              </div>

              <h3 className="text-xl font-semibold text-white mb-2">{template.name}</h3>
              <p className="text-gray-300 mb-4">{template.description}</p>

              <div className="flex flex-wrap gap-2 mb-4">
                <Badge variant="secondary">{template.difficulty}</Badge>
                <Badge variant="outline" className="text-gray-300">{template.controls}</Badge>
              </div>

              <ul className="text-sm text-gray-400 space-y-1 mb-4">
                {template.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <span className="w-2 h-2 bg-blue-400 rounded-full mr-2"></span>
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full ${
                  selectedTemplate === template.id
                    ? 'bg-blue-500 hover:bg-blue-600'
                    : 'bg-gray-600 hover:bg-gray-700'
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedTemplate(template.id);
                }}
              >
                {selectedTemplate === template.id ? 'Selected' : 'Select Template'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
