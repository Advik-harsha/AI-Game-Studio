import { GameEngine } from './GameEngine';

interface WhackTheMoleConfig {
  customization: any;
  parameters: any;
  previewMode?: boolean;
}

interface Mole {
  id: number;
  x: number;
  y: number;
  isUp: boolean;
  timeUp: number;
  isBonus: boolean;
  hit: boolean;
}

export default class WhackTheMole extends GameEngine {
  private moles: Mole[];
  private holes: Array<{ x: number; y: number; width: number; height: number }>;
  private moleSpeed: number;
  private maxMoles: number;
  private gameTime: number;
  private bonusChance: number;
  private score: number;
  private timeLeft: number;
  private lastMoleTime: number;
  private moleSize: number;
  private rows: number;
  private cols: number;

  constructor(canvas: HTMLCanvasElement, config: WhackTheMoleConfig) {
    super(canvas, config);
    
    // Game parameters
    this.moleSpeed = (config.parameters.moleSpeed || 1.5) * 1000; // Convert to ms
    this.maxMoles = config.parameters.moleCount || 3;
    this.gameTime = (config.parameters.gameTime || 60) * 1000; // Convert to ms
    this.bonusChance = config.parameters.bonusChance || 15;
    
    // Game state
    this.score = 0;
    this.timeLeft = this.gameTime;
    this.lastMoleTime = 0;
    this.moleSize = 60;
    this.rows = 3;
    this.cols = 3;
    
    // Setup holes and moles
    this.setupHoles();
    this.moles = [];
    
    this.setupControls();
    this.startGame();
  }

  private setupHoles() {
    this.holes = [];
    const spacing = 120;
    const startX = (this.canvas.width - (this.cols - 1) * spacing) / 2;
    const startY = (this.canvas.height - (this.rows - 1) * spacing) / 2;
    
    for (let row = 0; row < this.rows; row++) {
      for (let col = 0; col < this.cols; col++) {
        this.holes.push({
          x: startX + col * spacing - this.moleSize / 2,
          y: startY + row * spacing - this.moleSize / 2,
          width: this.moleSize,
          height: this.moleSize
        });
      }
    }
  }

  private setupControls() {
    const handleClick = (e: MouseEvent | TouchEvent) => {
      e.preventDefault();
      const rect = this.canvas.getBoundingClientRect();
      let clientX, clientY;
      
      if (e instanceof MouseEvent) {
        clientX = e.clientX;
        clientY = e.clientY;
      } else {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      }
      
      const x = (clientX - rect.left) * (this.canvas.width / rect.width);
      const y = (clientY - rect.top) * (this.canvas.height / rect.height);
      
      this.handleMoleClick(x, y);
    };

    this.canvas.addEventListener('click', handleClick);
    this.canvas.addEventListener('touchstart', handleClick);
  }

  private handleMoleClick(x: number, y: number) {
    for (const mole of this.moles) {
      if (mole.isUp && !mole.hit &&
          x >= mole.x && x <= mole.x + this.moleSize &&
          y >= mole.y && y <= mole.y + this.moleSize) {
        
        mole.hit = true;
        const points = mole.isBonus ? 50 : 10;
        this.score += points;
        this.playSound('hit');
        
        // Visual feedback
        setTimeout(() => {
          const index = this.moles.indexOf(mole);
          if (index > -1) {
            this.moles.splice(index, 1);
          }
        }, 200);
        
        break;
      }
    }
  }

  private startGame() {
    const gameLoop = () => {
      if (!this.isRunning) return;
      
      this.timeLeft -= 16; // Assuming 60fps
      
      if (this.timeLeft <= 0) {
        this.gameOver();
        return;
      }
      
      setTimeout(gameLoop, 16);
    };
    
    gameLoop();
  }

  update(): void {
    const now = Date.now();
    
    // Spawn new moles
    if (this.moles.filter(m => m.isUp).length < this.maxMoles &&
        now - this.lastMoleTime > Math.random() * 1000 + 500) {
      
      const availableHoles = this.holes.filter((hole, index) => 
        !this.moles.some(mole => 
          mole.x === hole.x && mole.y === hole.y && mole.isUp
        )
      );
      
      if (availableHoles.length > 0) {
        const hole = availableHoles[Math.floor(Math.random() * availableHoles.length)];
        const isBonus = Math.random() * 100 < this.bonusChance;
        
        this.moles.push({
          id: Date.now(),
          x: hole.x,
          y: hole.y,
          isUp: true,
          timeUp: now,
          isBonus,
          hit: false
        });
        
        this.lastMoleTime = now;
      }
    }
    
    // Update existing moles
    this.moles = this.moles.filter(mole => {
      if (mole.hit) return false;
      
      // Mole goes down after time
      if (now - mole.timeUp > this.moleSpeed) {
        return false;
      }
      
      return true;
    });
  }

  private gameOver() {
    this.isRunning = false;
    this.playSound('gameOver');
    
    setTimeout(() => {
      if (confirm(`Time's up! Score: ${this.score}\nPlay again?`)) {
        this.restart();
      }
    }, 100);
  }

  private restart() {
    this.score = 0;
    this.timeLeft = this.gameTime;
    this.lastMoleTime = 0;
    this.moles = [];
    this.isRunning = true;
    this.startGame();
  }

  render(): void {
    const ctx = this.ctx;
    
    // Clear canvas with background
    const bgColor = this.getCustomColor('background', '#90EE90');
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw holes
    ctx.fillStyle = '#8B4513';
    this.holes.forEach(hole => {
      ctx.beginPath();
      ctx.arc(hole.x + hole.width / 2, hole.y + hole.height / 2, hole.width / 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Hole rim
      ctx.strokeStyle = '#654321';
      ctx.lineWidth = 4;
      ctx.stroke();
    });

    // Draw moles
    this.moles.forEach(mole => {
      if (!mole.isUp || mole.hit) return;
      
      const centerX = mole.x + this.moleSize / 2;
      const centerY = mole.y + this.moleSize / 2;
      
      // Mole body
      const moleColor = mole.isBonus ? 
        this.getCustomColor('bonusMole', '#FFD700') : 
        this.getCustomColor('mainCharacter', '#8B4513');
      
      ctx.fillStyle = moleColor;
      ctx.beginPath();
      ctx.arc(centerX, centerY, this.moleSize * 0.35, 0, Math.PI * 2);
      ctx.fill();
      
      // Mole features
      ctx.fillStyle = mole.isBonus ? '#FF4500' : 'black';
      
      // Eyes
      ctx.beginPath();
      ctx.arc(centerX - 8, centerY - 5, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(centerX + 8, centerY - 5, 3, 0, Math.PI * 2);
      ctx.fill();
      
      // Nose
      ctx.beginPath();
      ctx.arc(centerX, centerY + 2, 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Bonus star effect
      if (mole.isBonus) {
        const time = Date.now() * 0.01;
        for (let i = 0; i < 8; i++) {
          const angle = (i / 8) * Math.PI * 2 + time;
          const x = centerX + Math.cos(angle) * (this.moleSize * 0.6);
          const y = centerY + Math.sin(angle) * (this.moleSize * 0.6);
          
          ctx.fillStyle = '#FFD700';
          ctx.beginPath();
          ctx.arc(x, y, 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    });

    // Draw UI
    this.drawUI();
  }

  private drawUI() {
    const ctx = this.ctx;
    
    // Score
    ctx.fillStyle = 'white';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'left';
    ctx.strokeText(`Score: ${this.score}`, 20, 40);
    ctx.fillText(`Score: ${this.score}`, 20, 40);
    
    // Time
    const timeSeconds = Math.max(0, Math.ceil(this.timeLeft / 1000));
    ctx.textAlign = 'right';
    ctx.strokeText(`Time: ${timeSeconds}`, this.canvas.width - 20, 40);
    ctx.fillText(`Time: ${timeSeconds}`, this.canvas.width - 20, 40);
    
    // Instructions
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.strokeText('Click the moles!', this.canvas.width / 2, this.canvas.height - 20);
    ctx.fillText('Click the moles!', this.canvas.width / 2, this.canvas.height - 20);
  }

  destroy(): void {
    super.destroy();
  }
}
