export abstract class GameEngine {
  protected canvas: HTMLCanvasElement;
  protected ctx: CanvasRenderingContext2D;
  protected isRunning: boolean;
  protected config: any;
  private animationId?: number;
  private sounds: Map<string, HTMLAudioElement>;

  constructor(canvas: HTMLCanvasElement, config: any) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.config = config;
    this.isRunning = false;
    this.sounds = new Map();
    
    // Set canvas size
    this.resizeCanvas();
    
    // Set up canvas for mobile
    canvas.style.touchAction = 'none';
    
    // Load sounds
    this.loadSounds();
  }

  private resizeCanvas() {
    const rect = this.canvas.getBoundingClientRect();
    this.canvas.width = rect.width;
    this.canvas.height = rect.height;
  }

  private loadSounds() {
    const soundFiles = ['hit', 'success', 'background'];
    
    soundFiles.forEach(soundName => {
      try {
        const audio = new Audio(`/sounds/${soundName}.mp3`);
        audio.preload = 'auto';
        audio.volume = 0.3;
        this.sounds.set(soundName, audio);
      } catch (error) {
        console.warn(`Could not load sound: ${soundName}`);
      }
    });
  }

  protected playSound(soundName: string) {
    const sound = this.sounds.get(soundName);
    if (sound && !this.config.previewMode) {
      sound.currentTime = 0;
      sound.play().catch(() => {
        // Ignore audio play errors in preview mode
      });
    }
  }

  protected getCustomColor(aspect: string, defaultColor: string): string {
    // Apply AI customization colors if available
    const customization = this.config.customization;
    
    if (customization && customization[`${aspect}Generated`]) {
      // In a real implementation, this would extract colors from the AI-generated assets
      // For now, return modified versions of the default colors
      const colors = {
        background: ['#87CEEB', '#FFB6C1', '#98FB98', '#DDA0DD', '#F0E68C'],
        mainCharacter: ['#FFD700', '#FF69B4', '#00CED1', '#FF6347', '#9370DB'],
        obstacles: ['#FF4500', '#DC143C', '#8B0000', '#FF1493', '#B22222'],
        environment: ['#8B4513', '#2E8B57', '#4682B4', '#6B8E23', '#CD853F']
      };
      
      const colorSet = colors[aspect as keyof typeof colors];
      if (colorSet) {
        return colorSet[Math.floor(Math.random() * colorSet.length)];
      }
    }
    
    return defaultColor;
  }

  public start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    this.gameLoop();
  }

  public stop() {
    this.isRunning = false;
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
  }

  public destroy() {
    this.stop();
    
    // Stop all sounds
    this.sounds.forEach(sound => {
      sound.pause();
      sound.currentTime = 0;
    });
    
    // Clear canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  private gameLoop = () => {
    if (!this.isRunning) return;
    
    this.update();
    this.render();
    
    this.animationId = requestAnimationFrame(this.gameLoop);
  };

  // Abstract methods that must be implemented by game classes
  abstract update(): void;
  abstract render(): void;
}
