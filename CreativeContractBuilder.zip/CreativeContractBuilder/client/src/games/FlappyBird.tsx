import { GameEngine } from './GameEngine';

interface FlappyBirdConfig {
  customization: any;
  parameters: any;
  previewMode?: boolean;
}

export default class FlappyBird extends GameEngine {
  private bird: { x: number; y: number; velocity: number; rotation: number };
  private pipes: Array<{ x: number; topHeight: number; passed: boolean }>;
  private gravity: number;
  private jumpForce: number;
  private pipeGap: number;
  private pipeSpeed: number;
  private score: number;
  private gameStarted: boolean;

  constructor(canvas: HTMLCanvasElement, config: FlappyBirdConfig) {
    super(canvas, config);
    
    // Game parameters with defaults
    this.gravity = config.parameters.gravity || 0.5;
    this.jumpForce = config.parameters.jumpForce || 12;
    this.pipeGap = config.parameters.pipeGap || 150;
    this.pipeSpeed = config.parameters.pipeSpeed || 3;
    
    // Game state
    this.bird = {
      x: this.canvas.width * 0.2,
      y: this.canvas.height / 2,
      velocity: 0,
      rotation: 0
    };
    
    this.pipes = [];
    this.score = 0;
    this.gameStarted = false;
    
    this.setupControls();
    this.generateInitialPipes();
  }

  private setupControls() {
    const jump = () => {
      if (!this.isRunning) return;
      
      if (!this.gameStarted) {
        this.gameStarted = true;
      }
      
      this.bird.velocity = -this.jumpForce;
      
      // Play jump sound if available
      this.playSound('jump');
    };

    // Desktop controls
    this.canvas.addEventListener('click', jump);
    document.addEventListener('keydown', (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        jump();
      }
    });

    // Mobile controls
    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      jump();
    });
  }

  private generateInitialPipes() {
    for (let i = 0; i < 3; i++) {
      this.pipes.push({
        x: this.canvas.width + i * 300,
        topHeight: Math.random() * (this.canvas.height - this.pipeGap - 100) + 50,
        passed: false
      });
    }
  }

  update(): void {
    if (!this.gameStarted) return;

    // Update bird physics
    this.bird.velocity += this.gravity;
    this.bird.y += this.bird.velocity;
    this.bird.rotation = Math.min(Math.max(this.bird.velocity * 0.1, -0.5), 0.5);

    // Update pipes
    this.pipes.forEach(pipe => {
      pipe.x -= this.pipeSpeed;
      
      // Check if bird passed pipe
      if (!pipe.passed && pipe.x + 50 < this.bird.x) {
        pipe.passed = true;
        this.score++;
        this.playSound('score');
      }
    });

    // Remove off-screen pipes and add new ones
    this.pipes = this.pipes.filter(pipe => pipe.x > -100);
    
    if (this.pipes.length < 3) {
      const lastPipe = this.pipes[this.pipes.length - 1];
      this.pipes.push({
        x: lastPipe.x + 300,
        topHeight: Math.random() * (this.canvas.height - this.pipeGap - 100) + 50,
        passed: false
      });
    }

    // Check collisions
    this.checkCollisions();
  }

  private checkCollisions() {
    const birdRadius = 20;
    
    // Ground and ceiling collision
    if (this.bird.y + birdRadius > this.canvas.height || this.bird.y - birdRadius < 0) {
      this.gameOver();
      return;
    }

    // Pipe collision
    for (const pipe of this.pipes) {
      if (this.bird.x + birdRadius > pipe.x && 
          this.bird.x - birdRadius < pipe.x + 50) {
        
        if (this.bird.y - birdRadius < pipe.topHeight || 
            this.bird.y + birdRadius > pipe.topHeight + this.pipeGap) {
          this.gameOver();
          return;
        }
      }
    }
  }

  private gameOver() {
    this.isRunning = false;
    this.playSound('gameOver');
    
    // Show game over screen
    setTimeout(() => {
      if (confirm(`Game Over! Score: ${this.score}\nPlay again?`)) {
        this.restart();
      }
    }, 100);
  }

  private restart() {
    this.bird = {
      x: this.canvas.width * 0.2,
      y: this.canvas.height / 2,
      velocity: 0,
      rotation: 0
    };
    
    this.pipes = [];
    this.generateInitialPipes();
    this.score = 0;
    this.gameStarted = false;
    this.isRunning = true;
  }

  render(): void {
    const ctx = this.ctx;
    
    // Clear canvas with background
    const bgColor = this.getCustomColor('background', '#87CEEB');
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw pipes
    const pipeColor = this.getCustomColor('obstacles', '#32CD32');
    ctx.fillStyle = pipeColor;
    
    this.pipes.forEach(pipe => {
      // Top pipe
      ctx.fillRect(pipe.x, 0, 50, pipe.topHeight);
      // Bottom pipe
      ctx.fillRect(pipe.x, pipe.topHeight + this.pipeGap, 50, this.canvas.height);
    });

    // Draw bird
    ctx.save();
    ctx.translate(this.bird.x, this.bird.y);
    ctx.rotate(this.bird.rotation);
    
    const birdColor = this.getCustomColor('mainCharacter', '#FFD700');
    ctx.fillStyle = birdColor;
    ctx.beginPath();
    ctx.arc(0, 0, 20, 0, Math.PI * 2);
    ctx.fill();
    
    // Bird details
    ctx.fillStyle = '#FF4500';
    ctx.beginPath();
    ctx.arc(8, -2, 3, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.restore();

    // Draw score
    ctx.fillStyle = 'white';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(this.score.toString(), this.canvas.width / 2, 50);

    // Draw instructions if game hasn't started
    if (!this.gameStarted) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
      
      ctx.fillStyle = 'white';
      ctx.font = 'bold 24px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('Click or Press Space to Start', this.canvas.width / 2, this.canvas.height / 2);
      ctx.fillText('Tap to Flap!', this.canvas.width / 2, this.canvas.height / 2 + 40);
    }
  }

  destroy(): void {
    super.destroy();
    // Remove event listeners
    document.removeEventListener('keydown', this.handleKeydown);
  }

  private handleKeydown = (e: KeyboardEvent) => {
    if (e.code === 'Space') {
      e.preventDefault();
    }
  };
}
