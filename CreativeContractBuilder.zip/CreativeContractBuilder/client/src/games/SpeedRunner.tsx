import { GameEngine } from './GameEngine';

interface SpeedRunnerConfig {
  customization: any;
  parameters: any;
  previewMode?: boolean;
}

export default class SpeedRunner extends GameEngine {
  private player: { x: number; y: number; width: number; height: number; onGround: boolean; velocityY: number };
  private obstacles: Array<{ x: number; y: number; width: number; height: number }>;
  private platforms: Array<{ x: number; y: number; width: number; height: number }>;
  private runSpeed: number;
  private jumpHeight: number;
  private obstacleFreq: number;
  private speedIncrease: number;
  private currentSpeed: number;
  private distance: number;
  private gravity: number;
  private keys: Set<string>;
  private lastObstacleTime: number;

  constructor(canvas: HTMLCanvasElement, config: SpeedRunnerConfig) {
    super(canvas, config);
    
    // Game parameters
    this.runSpeed = config.parameters.runSpeed || 5;
    this.jumpHeight = config.parameters.jumpHeight || 15;
    this.obstacleFreq = config.parameters.obstacleFreq || 2;
    this.speedIncrease = config.parameters.speedIncrease || 0.02;
    
    // Game state
    this.currentSpeed = this.runSpeed;
    this.distance = 0;
    this.gravity = 0.8;
    this.keys = new Set();
    this.lastObstacleTime = 0;
    
    // Player setup
    this.player = {
      x: 100,
      y: this.canvas.height - 150,
      width: 40,
      height: 60,
      onGround: true,
      velocityY: 0
    };
    
    // Initialize platforms and obstacles
    this.platforms = [
      { x: 0, y: this.canvas.height - 50, width: this.canvas.width * 3, height: 50 }
    ];
    this.obstacles = [];
    
    this.setupControls();
  }

  private setupControls() {
    // Desktop controls
    document.addEventListener('keydown', (e) => {
      this.keys.add(e.code);
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        this.jump();
      }
    });

    document.addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
    });

    // Mobile controls
    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      this.jump();
    });
  }

  private jump() {
    if (this.player.onGround) {
      this.player.velocityY = -this.jumpHeight;
      this.player.onGround = false;
      this.playSound('jump');
    }
  }

  update(): void {
    // Increase speed over time
    this.currentSpeed += this.speedIncrease;
    this.distance += this.currentSpeed;

    // Update player physics
    this.updatePlayer();
    
    // Generate obstacles
    this.generateObstacles();
    
    // Update obstacles
    this.updateObstacles();
    
    // Check collisions
    this.checkCollisions();
  }

  private updatePlayer() {
    // Apply gravity
    if (!this.player.onGround) {
      this.player.velocityY += this.gravity;
    }
    
    this.player.y += this.player.velocityY;
    
    // Ground collision
    const groundY = this.canvas.height - 50 - this.player.height;
    if (this.player.y >= groundY) {
      this.player.y = groundY;
      this.player.velocityY = 0;
      this.player.onGround = true;
    }
  }

  private generateObstacles() {
    const now = Date.now();
    const timeBetweenObstacles = 1000 / this.obstacleFreq;
    
    if (now - this.lastObstacleTime > timeBetweenObstacles) {
      // Generate different types of obstacles
      const obstacleType = Math.random();
      
      if (obstacleType < 0.7) {
        // Ground obstacle
        this.obstacles.push({
          x: this.canvas.width,
          y: this.canvas.height - 50 - 40,
          width: 30,
          height: 40
        });
      } else {
        // Floating obstacle
        this.obstacles.push({
          x: this.canvas.width,
          y: this.canvas.height - 50 - 120,
          width: 40,
          height: 20
        });
      }
      
      this.lastObstacleTime = now;
    }
  }

  private updateObstacles() {
    this.obstacles = this.obstacles.filter(obstacle => {
      obstacle.x -= this.currentSpeed;
      return obstacle.x + obstacle.width > 0;
    });
  }

  private checkCollisions() {
    for (const obstacle of this.obstacles) {
      if (this.player.x < obstacle.x + obstacle.width &&
          this.player.x + this.player.width > obstacle.x &&
          this.player.y < obstacle.y + obstacle.height &&
          this.player.y + this.player.height > obstacle.y) {
        this.gameOver();
        return;
      }
    }
  }

  private gameOver() {
    this.isRunning = false;
    this.playSound('gameOver');
    
    const score = Math.floor(this.distance / 10);
    setTimeout(() => {
      if (confirm(`Game Over! Distance: ${score}m\nPlay again?`)) {
        this.restart();
      }
    }, 100);
  }

  private restart() {
    this.player = {
      x: 100,
      y: this.canvas.height - 150,
      width: 40,
      height: 60,
      onGround: true,
      velocityY: 0
    };
    
    this.obstacles = [];
    this.currentSpeed = this.runSpeed;
    this.distance = 0;
    this.lastObstacleTime = 0;
    this.keys.clear();
    this.isRunning = true;
  }

  render(): void {
    const ctx = this.ctx;
    
    // Clear canvas with background
    const bgColor = this.getCustomColor('background', '#87CEEB');
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw moving background pattern
    const patternOffset = Math.floor(this.distance) % 50;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    for (let i = -patternOffset; i < this.canvas.width; i += 50) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, this.canvas.height);
      ctx.stroke();
    }

    // Draw platforms
    ctx.fillStyle = this.getCustomColor('environment', '#654321');
    this.platforms.forEach(platform => {
      ctx.fillRect(0, platform.y, this.canvas.width, platform.height);
    });

    // Draw obstacles
    ctx.fillStyle = this.getCustomColor('obstacles', '#FF4500');
    this.obstacles.forEach(obstacle => {
      ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    });

    // Draw player
    const playerColor = this.getCustomColor('mainCharacter', '#4169E1');
    ctx.fillStyle = playerColor;
    ctx.fillRect(this.player.x, this.player.y, this.player.width, this.player.height);
    
    // Player details
    ctx.fillStyle = 'white';
    ctx.fillRect(this.player.x + 10, this.player.y + 10, 8, 8); // Eye
    
    // Draw distance score
    ctx.fillStyle = 'white';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'left';
    const score = Math.floor(this.distance / 10);
    ctx.fillText(`Distance: ${score}m`, 20, 40);
    
    // Draw speed
    ctx.font = '16px Arial';
    ctx.fillText(`Speed: ${this.currentSpeed.toFixed(1)}`, 20, 70);

    // Draw instructions
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.font = '14px Arial';
    ctx.textAlign = 'right';
    ctx.fillText('Space/Tap to Jump', this.canvas.width - 20, 30);
  }

  destroy(): void {
    super.destroy();
    document.removeEventListener('keydown', this.handleKeydown);
    document.removeEventListener('keyup', this.handleKeyup);
  }

  private handleKeydown = (e: KeyboardEvent) => {
    this.keys.add(e.code);
  };

  private handleKeyup = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };
}
