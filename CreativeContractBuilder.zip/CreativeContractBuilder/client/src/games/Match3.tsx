import { GameEngine } from './GameEngine';

interface Match3Config {
  customization: any;
  parameters: any;
  previewMode?: boolean;
}

interface Gem {
  type: number;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  matched: boolean;
  falling: boolean;
}

export default class Match3 extends GameEngine {
  private grid: (Gem | null)[][];
  private gridSize: number;
  private matchReq: number;
  private moveLimit: number;
  private colorCount: number;
  private score: number;
  private movesLeft: number;
  private cellSize: number;
  private offsetX: number;
  private offsetY: number;
  private selectedGem: { row: number; col: number } | null;
  private dragging: boolean;
  private lastMatchTime: number;

  constructor(canvas: HTMLCanvasElement, config: Match3Config) {
    super(canvas, config);
    
    // Game parameters
    this.gridSize = config.parameters.gridSize || 8;
    this.matchReq = config.parameters.matchReq || 3;
    this.moveLimit = config.parameters.moveLimit || 20;
    this.colorCount = config.parameters.colorCount || 6;
    
    // Game state
    this.score = 0;
    this.movesLeft = this.moveLimit;
    this.selectedGem = null;
    this.dragging = false;
    this.lastMatchTime = 0;
    
    // Calculate grid layout
    this.cellSize = Math.min(
      (this.canvas.width - 40) / this.gridSize,
      (this.canvas.height - 120) / this.gridSize
    );
    
    this.offsetX = (this.canvas.width - this.gridSize * this.cellSize) / 2;
    this.offsetY = (this.canvas.height - this.gridSize * this.cellSize) / 2 + 20;
    
    this.initializeGrid();
    this.setupControls();
  }

  private initializeGrid() {
    this.grid = [];
    
    for (let row = 0; row < this.gridSize; row++) {
      this.grid[row] = [];
      for (let col = 0; col < this.gridSize; col++) {
        let gemType;
        do {
          gemType = Math.floor(Math.random() * this.colorCount);
        } while (this.wouldCreateMatch(row, col, gemType));
        
        this.grid[row][col] = {
          type: gemType,
          x: col,
          y: row,
          targetX: col,
          targetY: row,
          matched: false,
          falling: false
        };
      }
    }
  }

  private wouldCreateMatch(row: number, col: number, type: number): boolean {
    // Check horizontal match
    let horizontalCount = 1;
    for (let i = col - 1; i >= 0 && this.grid[row] && this.grid[row][i]?.type === type; i--) {
      horizontalCount++;
    }
    for (let i = col + 1; i < this.gridSize && this.grid[row] && this.grid[row][i]?.type === type; i++) {
      horizontalCount++;
    }
    
    // Check vertical match
    let verticalCount = 1;
    for (let i = row - 1; i >= 0 && this.grid[i] && this.grid[i][col]?.type === type; i--) {
      verticalCount++;
    }
    for (let i = row + 1; i < this.gridSize && this.grid[i] && this.grid[i][col]?.type === type; i++) {
      verticalCount++;
    }
    
    return horizontalCount >= this.matchReq || verticalCount >= this.matchReq;
  }

  private setupControls() {
    const getGridPosition = (x: number, y: number) => {
      const col = Math.floor((x - this.offsetX) / this.cellSize);
      const row = Math.floor((y - this.offsetY) / this.cellSize);
      
      if (row >= 0 && row < this.gridSize && col >= 0 && col < this.gridSize) {
        return { row, col };
      }
      return null;
    };

    const handleStart = (e: MouseEvent | TouchEvent) => {
      e.preventDefault();
      const rect = this.canvas.getBoundingClientRect();
      let clientX, clientY;
      
      if (e instanceof MouseEvent) {
        clientX = e.clientX;
        clientY = e.clientY;
      } else {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      }
      
      const x = (clientX - rect.left) * (this.canvas.width / rect.width);
      const y = (clientY - rect.top) * (this.canvas.height / rect.height);
      
      const pos = getGridPosition(x, y);
      if (pos) {
        this.selectedGem = pos;
        this.dragging = true;
      }
    };

    const handleEnd = (e: MouseEvent | TouchEvent) => {
      if (!this.dragging || !this.selectedGem) return;
      
      e.preventDefault();
      const rect = this.canvas.getBoundingClientRect();
      let clientX, clientY;
      
      if (e instanceof MouseEvent) {
        clientX = e.clientX;
        clientY = e.clientY;
      } else {
        clientX = e.changedTouches[0].clientX;
        clientY = e.changedTouches[0].clientY;
      }
      
      const x = (clientX - rect.left) * (this.canvas.width / rect.width);
      const y = (clientY - rect.top) * (this.canvas.height / rect.height);
      
      const pos = getGridPosition(x, y);
      if (pos && this.isAdjacent(this.selectedGem, pos)) {
        this.attemptSwap(this.selectedGem, pos);
      }
      
      this.selectedGem = null;
      this.dragging = false;
    };

    this.canvas.addEventListener('mousedown', handleStart);
    this.canvas.addEventListener('mouseup', handleEnd);
    this.canvas.addEventListener('touchstart', handleStart);
    this.canvas.addEventListener('touchend', handleEnd);
  }

  private isAdjacent(pos1: { row: number; col: number }, pos2: { row: number; col: number }): boolean {
    const rowDiff = Math.abs(pos1.row - pos2.row);
    const colDiff = Math.abs(pos1.col - pos2.col);
    return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
  }

  private attemptSwap(pos1: { row: number; col: number }, pos2: { row: number; col: number }) {
    const gem1 = this.grid[pos1.row][pos1.col];
    const gem2 = this.grid[pos2.row][pos2.col];
    
    if (!gem1 || !gem2) return;
    
    // Temporarily swap
    this.grid[pos1.row][pos1.col] = gem2;
    this.grid[pos2.row][pos2.col] = gem1;
    
    // Update positions
    gem1.x = pos2.col;
    gem1.y = pos2.row;
    gem2.x = pos1.col;
    gem2.y = pos1.row;
    
    // Check for matches
    const matches = this.findMatches();
    
    if (matches.length > 0) {
      this.movesLeft--;
      this.processMatches(matches);
      this.playSound('match');
    } else {
      // Swap back if no matches
      this.grid[pos1.row][pos1.col] = gem1;
      this.grid[pos2.row][pos2.col] = gem2;
      gem1.x = pos1.col;
      gem1.y = pos1.row;
      gem2.x = pos2.col;
      gem2.y = pos2.row;
    }
  }

  private findMatches(): Array<{ row: number; col: number }> {
    const matches = new Set<string>();
    
    // Find horizontal matches
    for (let row = 0; row < this.gridSize; row++) {
      let count = 1;
      let currentType = this.grid[row][0]?.type;
      
      for (let col = 1; col < this.gridSize; col++) {
        const gem = this.grid[row][col];
        if (gem && gem.type === currentType) {
          count++;
        } else {
          if (count >= this.matchReq) {
            for (let i = col - count; i < col; i++) {
              matches.add(`${row}-${i}`);
            }
          }
          count = 1;
          currentType = gem?.type;
        }
      }
      
      if (count >= this.matchReq) {
        for (let i = this.gridSize - count; i < this.gridSize; i++) {
          matches.add(`${row}-${i}`);
        }
      }
    }
    
    // Find vertical matches
    for (let col = 0; col < this.gridSize; col++) {
      let count = 1;
      let currentType = this.grid[0][col]?.type;
      
      for (let row = 1; row < this.gridSize; row++) {
        const gem = this.grid[row][col];
        if (gem && gem.type === currentType) {
          count++;
        } else {
          if (count >= this.matchReq) {
            for (let i = row - count; i < row; i++) {
              matches.add(`${i}-${col}`);
            }
          }
          count = 1;
          currentType = gem?.type;
        }
      }
      
      if (count >= this.matchReq) {
        for (let i = this.gridSize - count; i < this.gridSize; i++) {
          matches.add(`${i}-${col}`);
        }
      }
    }
    
    return Array.from(matches).map(pos => {
      const [row, col] = pos.split('-').map(Number);
      return { row, col };
    });
  }

  private processMatches(matches: Array<{ row: number; col: number }>) {
    // Mark gems as matched
    matches.forEach(({ row, col }) => {
      const gem = this.grid[row][col];
      if (gem) {
        gem.matched = true;
        this.score += 10;
      }
    });
    
    this.lastMatchTime = Date.now();
    
    // Remove matched gems after animation
    setTimeout(() => {
      this.removeMatchedGems();
      this.dropGems();
      this.fillEmptySpaces();
    }, 300);
  }

  private removeMatchedGems() {
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        const gem = this.grid[row][col];
        if (gem && gem.matched) {
          this.grid[row][col] = null;
        }
      }
    }
  }

  private dropGems() {
    for (let col = 0; col < this.gridSize; col++) {
      let writeIndex = this.gridSize - 1;
      
      for (let row = this.gridSize - 1; row >= 0; row--) {
        const gem = this.grid[row][col];
        if (gem) {
          if (writeIndex !== row) {
            this.grid[writeIndex][col] = gem;
            this.grid[row][col] = null;
            gem.y = writeIndex;
            gem.falling = true;
          }
          writeIndex--;
        }
      }
    }
  }

  private fillEmptySpaces() {
    for (let col = 0; col < this.gridSize; col++) {
      for (let row = 0; row < this.gridSize; row++) {
        if (!this.grid[row][col]) {
          this.grid[row][col] = {
            type: Math.floor(Math.random() * this.colorCount),
            x: col,
            y: row,
            targetX: col,
            targetY: row,
            matched: false,
            falling: true
          };
        }
      }
    }
  }

  update(): void {
    if (this.movesLeft <= 0) {
      this.gameOver();
      return;
    }
    
    // Update gem animations
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        const gem = this.grid[row][col];
        if (gem && gem.falling) {
          gem.falling = false;
        }
      }
    }
    
    // Check for new matches after drops
    const matches = this.findMatches();
    if (matches.length > 0) {
      this.processMatches(matches);
    }
  }

  private gameOver() {
    this.isRunning = false;
    this.playSound('gameOver');
    
    setTimeout(() => {
      if (confirm(`Game Over! Score: ${this.score}\nPlay again?`)) {
        this.restart();
      }
    }, 100);
  }

  private restart() {
    this.score = 0;
    this.movesLeft = this.moveLimit;
    this.selectedGem = null;
    this.dragging = false;
    this.lastMatchTime = 0;
    this.initializeGrid();
    this.isRunning = true;
  }

  render(): void {
    const ctx = this.ctx;
    
    // Clear canvas with background
    const bgColor = this.getCustomColor('background', '#4B0082');
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw grid
    this.drawGrid();
    
    // Draw gems
    this.drawGems();
    
    // Draw UI
    this.drawUI();
  }

  private drawGrid() {
    const ctx = this.ctx;
    
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 1;
    
    for (let row = 0; row <= this.gridSize; row++) {
      const y = this.offsetY + row * this.cellSize;
      ctx.beginPath();
      ctx.moveTo(this.offsetX, y);
      ctx.lineTo(this.offsetX + this.gridSize * this.cellSize, y);
      ctx.stroke();
    }
    
    for (let col = 0; col <= this.gridSize; col++) {
      const x = this.offsetX + col * this.cellSize;
      ctx.beginPath();
      ctx.moveTo(x, this.offsetY);
      ctx.lineTo(x, this.offsetY + this.gridSize * this.cellSize);
      ctx.stroke();
    }
  }

  private drawGems() {
    const ctx = this.ctx;
    const gemColors = [
      '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080'
    ];
    
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        const gem = this.grid[row][col];
        if (!gem) continue;
        
        const x = this.offsetX + col * this.cellSize;
        const y = this.offsetY + row * this.cellSize;
        
        // Highlight selected gem
        if (this.selectedGem && this.selectedGem.row === row && this.selectedGem.col === col) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
          ctx.fillRect(x, y, this.cellSize, this.cellSize);
        }
        
        // Draw gem with match animation
        const now = Date.now();
        const timeSinceMatch = now - this.lastMatchTime;
        let scale = 1;
        
        if (gem.matched && timeSinceMatch < 300) {
          scale = 1 - (timeSinceMatch / 300);
        }
        
        const gemSize = this.cellSize * 0.8 * scale;
        const gemX = x + (this.cellSize - gemSize) / 2;
        const gemY = y + (this.cellSize - gemSize) / 2;
        
        ctx.fillStyle = gemColors[gem.type] || '#FFFFFF';
        ctx.beginPath();
        ctx.arc(
          gemX + gemSize / 2,
          gemY + gemSize / 2,
          gemSize / 2,
          0,
          Math.PI * 2
        );
        ctx.fill();
        
        // Gem shine effect
        if (!gem.matched) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
          ctx.beginPath();
          ctx.arc(
            gemX + gemSize / 2 - gemSize * 0.2,
            gemY + gemSize / 2 - gemSize * 0.2,
            gemSize * 0.15,
            0,
            Math.PI * 2
          );
          ctx.fill();
        }
      }
    }
  }

  private drawUI() {
    const ctx = this.ctx;
    
    // Score
    ctx.fillStyle = 'white';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'left';
    ctx.strokeText(`Score: ${this.score}`, 20, 40);
    ctx.fillText(`Score: ${this.score}`, 20, 40);
    
    // Moves left
    ctx.textAlign = 'right';
    ctx.strokeText(`Moves: ${this.movesLeft}`, this.canvas.width - 20, 40);
    ctx.fillText(`Moves: ${this.movesLeft}`, this.canvas.width - 20, 40);
    
    // Instructions
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.strokeText('Drag to swap gems', this.canvas.width / 2, this.canvas.height - 20);
    ctx.fillText('Drag to swap gems', this.canvas.width / 2, this.canvas.height - 20);
  }

  destroy(): void {
    super.destroy();
  }
}
