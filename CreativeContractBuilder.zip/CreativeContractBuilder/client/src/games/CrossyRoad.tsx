import { GameEngine } from './GameEngine';

interface CrossyRoadConfig {
  customization: any;
  parameters: any;
  previewMode?: boolean;
}

interface Vehicle {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  direction: number;
}

interface Lane {
  type: 'road' | 'river' | 'safe';
  y: number;
  vehicles: Vehicle[];
  direction: number;
}

export default class CrossyRoad extends GameEngine {
  private player: { x: number; y: number; width: number; height: number; onLog: boolean };
  private lanes: Lane[];
  private laneWidth: number;
  private carSpeed: number;
  private carDensity: number;
  private riverSpeed: number;
  private score: number;
  private camera: { y: number };
  private keys: Set<string>;
  private lastMoveTime: number;

  constructor(canvas: HTMLCanvasElement, config: CrossyRoadConfig) {
    super(canvas, config);
    
    // Game parameters
    this.laneWidth = config.parameters.laneWidth || 50;
    this.carSpeed = config.parameters.carSpeed || 3;
    this.carDensity = config.parameters.carDensity || 0.3;
    this.riverSpeed = config.parameters.riverSpeed || 2;
    
    // Game state
    this.score = 0;
    this.keys = new Set();
    this.lastMoveTime = 0;
    
    // Player setup
    this.player = {
      x: this.canvas.width / 2,
      y: this.canvas.height - this.laneWidth / 2,
      width: 30,
      height: 30,
      onLog: false
    };
    
    // Camera
    this.camera = { y: 0 };
    
    // Initialize lanes
    this.setupLanes();
    this.setupControls();
  }

  private setupLanes() {
    this.lanes = [];
    
    // Start with safe lane
    this.lanes.push({
      type: 'safe',
      y: this.canvas.height - this.laneWidth,
      vehicles: [],
      direction: 0
    });
    
    // Generate initial lanes
    for (let i = 1; i < 20; i++) {
      const laneType = Math.random() < 0.6 ? 'road' : 'river';
      const direction = Math.random() < 0.5 ? -1 : 1;
      
      this.lanes.push({
        type: laneType,
        y: this.canvas.height - this.laneWidth * (i + 1),
        vehicles: [],
        direction
      });
      
      this.generateVehiclesForLane(this.lanes[this.lanes.length - 1]);
    }
  }

  private generateVehiclesForLane(lane: Lane) {
    if (lane.type === 'safe') return;
    
    const vehicleCount = Math.floor(Math.random() * 3) + 1;
    const spacing = this.canvas.width / vehicleCount;
    
    for (let i = 0; i < vehicleCount; i++) {
      if (Math.random() < this.carDensity) {
        const vehicle: Vehicle = {
          x: i * spacing + Math.random() * spacing,
          y: lane.y + this.laneWidth / 2,
          width: lane.type === 'road' ? 60 : 80,
          height: 30,
          speed: lane.type === 'road' ? this.carSpeed : this.riverSpeed,
          direction: lane.direction
        };
        
        lane.vehicles.push(vehicle);
      }
    }
  }

  private setupControls() {
    const moveDistance = this.laneWidth;
    const moveDelay = 200; // ms
    
    const move = (dx: number, dy: number) => {
      const now = Date.now();
      if (now - this.lastMoveTime < moveDelay) return;
      
      this.player.x += dx;
      this.player.y += dy;
      this.lastMoveTime = now;
      
      // Update score based on forward progress
      if (dy < 0) {
        this.score = Math.max(this.score, Math.floor((this.canvas.height - this.player.y) / this.laneWidth));
      }
      
      // Constrain player to canvas width
      this.player.x = Math.max(this.player.width / 2, 
        Math.min(this.canvas.width - this.player.width / 2, this.player.x));
      
      this.playSound('move');
    };

    // Desktop controls
    document.addEventListener('keydown', (e) => {
      this.keys.add(e.code);
      
      switch (e.code) {
        case 'ArrowUp':
        case 'KeyW':
          e.preventDefault();
          move(0, -moveDistance);
          break;
        case 'ArrowDown':
        case 'KeyS':
          e.preventDefault();
          move(0, moveDistance);
          break;
        case 'ArrowLeft':
        case 'KeyA':
          e.preventDefault();
          move(-moveDistance, 0);
          break;
        case 'ArrowRight':
        case 'KeyD':
          e.preventDefault();
          move(moveDistance, 0);
          break;
      }
    });

    document.addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
    });

    // Mobile swipe controls
    let touchStart = { x: 0, y: 0 };
    
    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      const touch = e.touches[0];
      const rect = this.canvas.getBoundingClientRect();
      touchStart.x = touch.clientX - rect.left;
      touchStart.y = touch.clientY - rect.top;
    });

    this.canvas.addEventListener('touchend', (e) => {
      e.preventDefault();
      const touch = e.changedTouches[0];
      const rect = this.canvas.getBoundingClientRect();
      const deltaX = (touch.clientX - rect.left) - touchStart.x;
      const deltaY = (touch.clientY - rect.top) - touchStart.y;
      
      const minSwipeDistance = 30;
      
      if (Math.abs(deltaX) > Math.abs(deltaY)) {
        if (Math.abs(deltaX) > minSwipeDistance) {
          move(deltaX > 0 ? moveDistance : -moveDistance, 0);
        }
      } else {
        if (Math.abs(deltaY) > minSwipeDistance) {
          move(0, deltaY > 0 ? moveDistance : -moveDistance);
        }
      }
    });
  }

  update(): void {
    // Update camera to follow player
    const targetCameraY = this.player.y - this.canvas.height * 0.7;
    this.camera.y += (targetCameraY - this.camera.y) * 0.1;
    
    // Update vehicles
    this.updateVehicles();
    
    // Generate new lanes as player progresses
    this.generateNewLanes();
    
    // Check collisions
    this.checkCollisions();
  }

  private updateVehicles() {
    this.lanes.forEach(lane => {
      lane.vehicles.forEach(vehicle => {
        vehicle.x += vehicle.speed * vehicle.direction;
        
        // Wrap around screen
        if (vehicle.direction > 0 && vehicle.x > this.canvas.width + vehicle.width) {
          vehicle.x = -vehicle.width;
        } else if (vehicle.direction < 0 && vehicle.x < -vehicle.width) {
          vehicle.x = this.canvas.width + vehicle.width;
        }
      });
    });
    
    // Update player position if on log
    this.player.onLog = false;
    const currentLane = this.getCurrentLane();
    
    if (currentLane && currentLane.type === 'river') {
      for (const vehicle of currentLane.vehicles) {
        if (this.isPlayerOnVehicle(vehicle)) {
          this.player.x += vehicle.speed * vehicle.direction;
          this.player.onLog = true;
          break;
        }
      }
      
      // Drown if not on log
      if (!this.player.onLog) {
        this.gameOver('You fell in the water!');
        return;
      }
    }
  }

  private getCurrentLane(): Lane | null {
    return this.lanes.find(lane => 
      Math.abs(this.player.y - (lane.y + this.laneWidth / 2)) < this.laneWidth / 2
    ) || null;
  }

  private isPlayerOnVehicle(vehicle: Vehicle): boolean {
    return this.player.x + this.player.width / 2 > vehicle.x &&
           this.player.x - this.player.width / 2 < vehicle.x + vehicle.width &&
           Math.abs(this.player.y - vehicle.y) < vehicle.height / 2;
  }

  private generateNewLanes() {
    const highestLane = Math.min(...this.lanes.map(l => l.y));
    
    if (highestLane > this.camera.y - this.canvas.height) {
      const newLaneY = highestLane - this.laneWidth;
      const laneType = Math.random() < 0.6 ? 'road' : 'river';
      const direction = Math.random() < 0.5 ? -1 : 1;
      
      const newLane: Lane = {
        type: laneType,
        y: newLaneY,
        vehicles: [],
        direction
      };
      
      this.generateVehiclesForLane(newLane);
      this.lanes.push(newLane);
    }
    
    // Remove lanes that are too far behind
    this.lanes = this.lanes.filter(lane => 
      lane.y < this.camera.y + this.canvas.height + 200
    );
  }

  private checkCollisions() {
    const currentLane = this.getCurrentLane();
    
    if (currentLane && currentLane.type === 'road') {
      for (const vehicle of currentLane.vehicles) {
        if (this.isPlayerOnVehicle(vehicle)) {
          this.gameOver('Hit by a car!');
          return;
        }
      }
    }
    
    // Check if player went off screen
    if (this.player.x < 0 || this.player.x > this.canvas.width) {
      this.gameOver('Went off the road!');
    }
  }

  private gameOver(reason: string) {
    this.isRunning = false;
    this.playSound('gameOver');
    
    setTimeout(() => {
      if (confirm(`${reason}\nScore: ${this.score}\nPlay again?`)) {
        this.restart();
      }
    }, 100);
  }

  private restart() {
    this.player = {
      x: this.canvas.width / 2,
      y: this.canvas.height - this.laneWidth / 2,
      width: 30,
      height: 30,
      onLog: false
    };
    
    this.camera = { y: 0 };
    this.score = 0;
    this.keys.clear();
    this.lastMoveTime = 0;
    this.setupLanes();
    this.isRunning = true;
  }

  render(): void {
    const ctx = this.ctx;
    
    // Clear canvas
    ctx.fillStyle = this.getCustomColor('background', '#90EE90');
    ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    ctx.save();
    ctx.translate(0, -this.camera.y);

    // Draw lanes
    this.lanes.forEach(lane => {
      const laneColor = lane.type === 'road' ? '#808080' : 
                       lane.type === 'river' ? '#0077BE' : '#90EE90';
      
      ctx.fillStyle = laneColor;
      ctx.fillRect(0, lane.y, this.canvas.width, this.laneWidth);
      
      // Lane borders
      ctx.strokeStyle = 'white';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, lane.y);
      ctx.lineTo(this.canvas.width, lane.y);
      ctx.stroke();
    });

    // Draw vehicles
    this.lanes.forEach(lane => {
      lane.vehicles.forEach(vehicle => {
        const vehicleColor = lane.type === 'road' ? 
          this.getCustomColor('obstacles', '#FF4500') :
          this.getCustomColor('environment', '#8B4513');
        
        ctx.fillStyle = vehicleColor;
        ctx.fillRect(
          vehicle.x - vehicle.width / 2,
          vehicle.y - vehicle.height / 2,
          vehicle.width,
          vehicle.height
        );
        
        // Vehicle details
        if (lane.type === 'road') {
          // Car windows
          ctx.fillStyle = '#333';
          ctx.fillRect(
            vehicle.x - vehicle.width / 2 + 10,
            vehicle.y - vehicle.height / 2 + 5,
            vehicle.width - 20,
            vehicle.height - 10
          );
        } else {
          // Log texture
          ctx.strokeStyle = '#654321';
          ctx.lineWidth = 2;
          for (let i = 0; i < 3; i++) {
            const y = vehicle.y - vehicle.height / 2 + (i + 1) * vehicle.height / 4;
            ctx.beginPath();
            ctx.moveTo(vehicle.x - vehicle.width / 2, y);
            ctx.lineTo(vehicle.x + vehicle.width / 2, y);
            ctx.stroke();
          }
        }
      });
    });

    // Draw player
    const playerColor = this.getCustomColor('mainCharacter', '#FFD700');
    ctx.fillStyle = playerColor;
    ctx.fillRect(
      this.player.x - this.player.width / 2,
      this.player.y - this.player.height / 2,
      this.player.width,
      this.player.height
    );
    
    // Player details
    ctx.fillStyle = 'black';
    ctx.fillRect(
      this.player.x - 5,
      this.player.y - 10,
      3,
      3
    );
    ctx.fillRect(
      this.player.x + 2,
      this.player.y - 10,
      3,
      3
    );

    ctx.restore();

    // Draw UI
    this.drawUI();
  }

  private drawUI() {
    const ctx = this.ctx;
    
    // Score
    ctx.fillStyle = 'white';
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'left';
    ctx.strokeText(`Score: ${this.score}`, 20, 40);
    ctx.fillText(`Score: ${this.score}`, 20, 40);
    
    // Instructions
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.strokeText('WASD/Arrows or Swipe to move', this.canvas.width / 2, this.canvas.height - 20);
    ctx.fillText('WASD/Arrows or Swipe to move', this.canvas.width / 2, this.canvas.height - 20);
  }

  destroy(): void {
    super.destroy();
    document.removeEventListener('keydown', this.handleKeydown);
    document.removeEventListener('keyup', this.handleKeyup);
  }

  private handleKeydown = (e: KeyboardEvent) => {
    this.keys.add(e.code);
  };

  private handleKeyup = (e: KeyboardEvent) => {
    this.keys.delete(e.code);
  };
}
