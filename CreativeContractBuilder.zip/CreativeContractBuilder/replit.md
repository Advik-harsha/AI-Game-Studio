# AI Game Studio

## Overview

This is a web-based AI-powered game creation tool that allows users to create and customize classic games without any coding knowledge. The platform provides five classic game templates (Flappy Bird, Speed Runner, Whack-the-Mole, Match-3, and Crossy Road) that users can customize using AI-generated assets and parameters, then export as playable HTML5 games.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with a comprehensive design system using Radix UI components
- **State Management**: Zustand for lightweight state management
- **Data Fetching**: React Query (@tanstack/react-query) for server state management
- **3D Graphics**: React Three Fiber ecosystem for potential 3D game elements

### Backend Architecture
- **Runtime**: Node.js with Express.js REST API
- **Language**: TypeScript for full-stack type safety
- **API Design**: RESTful endpoints organized by feature (AI services, game export)
- **Development**: Hot reload with Vite integration for seamless development experience

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Simple user management system with room for expansion
- **Migrations**: Drizzle-kit for database schema management
- **Development Storage**: In-memory storage for rapid development iteration

## Key Components

### AI Integration
- **Provider**: OpenAI GPT-4o for asset generation and game parameter optimization
- **Asset Generation**: Text-to-description conversion for game elements (characters, backgrounds, obstacles)
- **Parameter Tuning**: AI-driven game balance and difficulty adjustment
- **Response Format**: Structured JSON responses for consistent integration

### Game Engine System
- **Base Engine**: Custom HTML5 Canvas-based game engine with shared functionality
- **Game Templates**: Five classic games implemented as separate classes extending the base engine
- **Customization**: Dynamic asset and parameter injection system
- **Preview Mode**: Real-time game preview during customization process

### User Interface
- **Wizard Flow**: Step-by-step guided process (Pick Template → AI Reskin → Set Parameters → Export)
- **Component Library**: Comprehensive UI components built on Radix UI primitives
- **Responsive Design**: Mobile-first approach with touch-friendly controls
- **Real-time Feedback**: Live preview and immediate visual feedback

### Export System
- **Format**: ZIP file containing complete HTML5 game
- **Structure**: Self-contained game with index.html, game logic, styles, and assets
- **Offline Capability**: Exported games run without internet connection
- **Cross-platform**: Compatible with modern web browsers

## Data Flow

1. **Template Selection**: User chooses from five predefined game templates
2. **AI Customization**: User provides prompts for different game aspects (theme, characters, environment)
3. **Asset Generation**: OpenAI API generates descriptions and color schemes based on prompts
4. **Parameter Tuning**: AI suggests game parameters based on difficulty and theme
5. **Real-time Preview**: Game engine renders customized game with new assets and parameters
6. **Export Generation**: Server creates complete HTML5 game package as downloadable ZIP

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4o model for content generation
- **Rate Limiting**: Built-in error handling and retry logic
- **Fallback Strategy**: Graceful degradation when AI services are unavailable

### Development Tools
- **Neon Database**: PostgreSQL hosting for production database
- **Vite Plugins**: Enhanced development experience with error overlays and GLSL shader support
- **ESBuild**: Fast bundling for production builds

### UI Libraries
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **React Three Fiber**: 3D graphics capabilities for enhanced visual effects

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: ESBuild bundles server code for Node.js deployment
- **Database**: Drizzle migrations ensure schema consistency across environments

### Environment Configuration
- **Development**: Hot reload with Vite dev server integration
- **Production**: Optimized builds with static asset serving
- **Database**: Environment-specific connection strings and credentials

### Scalability Considerations
- **Stateless Design**: Server can be horizontally scaled
- **Database Connection**: Pooled connections for efficient resource usage
- **AI API**: Configurable rate limiting and caching strategies
- **File Storage**: ZIP generation can be moved to cloud storage for larger scale