import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || "default_key"
});

export interface AIGenerationResponse {
  assets?: {
    images?: string[];
    colors?: string[];
    descriptions?: string[];
  };
  success: boolean;
  message?: string;
}

export interface GameParametersResponse {
  parameters: Record<string, number>;
  success: boolean;
  message?: string;
}

export async function generateAssets(
  gameTemplate: string,
  aspect: string,
  prompt: string
): Promise<AIGenerationResponse> {
  try {
    const systemPrompt = `You are an AI game asset generator. Generate creative descriptions and color schemes for game assets based on the user's prompt. 

Game Template: ${gameTemplate}
Asset Type: ${aspect}

Return a JSON object with the following structure:
{
  "assets": {
    "descriptions": ["detailed description of the asset"],
    "colors": ["#hexcolor1", "#hexcolor2", "#hexcolor3"],
    "style": "description of the visual style"
  },
  "success": true,
  "message": "Generated successfully"
}

Focus on creating vivid, game-appropriate descriptions that match the requested theme and style.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
      temperature: 0.8
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      assets: result.assets || {},
      success: true,
      message: result.message || 'Assets generated successfully'
    };
  } catch (error) {
    console.error('OpenAI asset generation error:', error);
    return {
      success: false,
      message: 'Failed to generate assets with AI. Please try a different prompt.'
    };
  }
}

export async function generateParameters(
  gameTemplate: string,
  prompt: string,
  difficulty: string
): Promise<GameParametersResponse> {
  try {
    const gameParameterSpecs = {
      'flappy-bird': {
        gravity: { min: 0.1, max: 2, default: 0.5 },
        jumpForce: { min: 5, max: 20, default: 12 },
        pipeGap: { min: 100, max: 300, default: 150 },
        pipeSpeed: { min: 1, max: 10, default: 3 }
      },
      'speed-runner': {
        runSpeed: { min: 2, max: 15, default: 5 },
        jumpHeight: { min: 50, max: 200, default: 100 },
        obstacleFreq: { min: 0.5, max: 5, default: 2 },
        speedIncrease: { min: 0.01, max: 0.1, default: 0.02 }
      },
      'whack-the-mole': {
        moleSpeed: { min: 0.5, max: 3, default: 1.5 },
        moleCount: { min: 1, max: 6, default: 3 },
        gameTime: { min: 30, max: 180, default: 60 },
        bonusChance: { min: 0, max: 30, default: 15 }
      },
      'match3': {
        gridSize: { min: 6, max: 10, default: 8 },
        matchReq: { min: 3, max: 5, default: 3 },
        moveLimit: { min: 10, max: 50, default: 20 },
        colorCount: { min: 4, max: 8, default: 6 }
      },
      'crossy-road': {
        laneWidth: { min: 30, max: 80, default: 50 },
        carSpeed: { min: 1, max: 8, default: 3 },
        carDensity: { min: 0.1, max: 0.8, default: 0.3 },
        riverSpeed: { min: 0.5, max: 4, default: 2 }
      }
    };

    const specs = gameParameterSpecs[gameTemplate as keyof typeof gameParameterSpecs];
    if (!specs) {
      throw new Error(`Unknown game template: ${gameTemplate}`);
    }

    const systemPrompt = `You are a game parameter tuning AI. Adjust game parameters based on the user's request and difficulty level.

Game Template: ${gameTemplate}
Difficulty: ${difficulty}
Available Parameters: ${JSON.stringify(specs, null, 2)}

User Request: "${prompt}"

Generate parameters that match the user's intent while staying within the specified ranges. For difficulty levels:
- Easy: Lower challenge values (closer to min for difficulty parameters)
- Medium: Balanced values (around default)
- Hard: Higher challenge values (closer to max for difficulty parameters)

Return a JSON object with this structure:
{
  "parameters": {
    "paramName": number,
    ...
  },
  "success": true,
  "message": "Parameters adjusted successfully"
}

Only include parameters that exist in the specs. All values must be numbers within the specified ranges.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
      max_tokens: 800,
      temperature: 0.3
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    // Validate and clamp parameters to specified ranges
    const validatedParameters: Record<string, number> = {};
    
    if (result.parameters) {
      for (const [key, value] of Object.entries(result.parameters)) {
        if (key in specs && typeof value === 'number') {
          const spec = specs[key as keyof typeof specs];
          validatedParameters[key] = Math.max(spec.min, Math.min(spec.max, value));
        }
      }
    }

    return {
      parameters: validatedParameters,
      success: true,
      message: result.message || 'Parameters generated successfully'
    };
  } catch (error) {
    console.error('OpenAI parameter generation error:', error);
    return {
      success: false,
      message: 'Failed to generate parameters with AI. Please try a different prompt.',
      parameters: {}
    };
  }
}
