import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface ExportConfig {
  gameName: string;
  description: string;
  author: string;
  version: string;
  includeSource: boolean;
}

export async function exportGameAsZip(
  templateId: string,
  gameData: any,
  config: ExportConfig
): Promise<Buffer> {
  try {
    // Create the game HTML content
    const gameHtml = generateGameHTML(templateId, gameData, config);
    
    // For now, return a simple ZIP-like structure as a Buffer
    // In a production environment, you would use a proper ZIP library like 'archiver'
    const zipContent = createSimpleZip({
      'index.html': gameHtml,
      'game.js': generateGameJS(templateId, gameData),
      'style.css': generateGameCSS(gameData),
      'README.txt': generateReadme(config)
    });

    return Buffer.from(zipContent);
  } catch (error) {
    console.error('Error creating game export:', error);
    throw new Error('Failed to create game export');
  }
}

function generateGameHTML(templateId: string, gameData: any, config: ExportConfig): string {
  const customization = gameData.customization || {};
  const parameters = gameData.parameters || {};

  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${config.gameName}</title>
    <meta name="description" content="${config.description}">
    <meta name="author" content="${config.author}">
    <meta name="version" content="${config.version}">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: ${getBackgroundColor(customization)};
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
        }
        
        #gameContainer {
            position: relative;
            border: 2px solid #333;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        
        #gameCanvas {
            display: block;
            background: ${getBackgroundColor(customization)};
            touch-action: none;
        }
        
        #gameInfo {
            position: absolute;
            top: 10px;
            left: 10px;
            color: white;
            font-size: 14px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
        }
        
        .mobile-controls {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: none;
        }
        
        @media (max-width: 768px) {
            .mobile-controls {
                display: flex;
                gap: 10px;
            }
            
            .control-btn {
                width: 60px;
                height: 60px;
                border: none;
                border-radius: 50%;
                background: rgba(255,255,255,0.8);
                font-size: 20px;
                touch-action: manipulation;
                user-select: none;
            }
        }
    </style>
</head>
<body>
    <div id="gameContainer">
        <canvas id="gameCanvas" width="800" height="600"></canvas>
        <div id="gameInfo">
            <div>${config.gameName}</div>
            <div>by ${config.author}</div>
        </div>
        
        <div class="mobile-controls">
            ${getMobileControls(templateId)}
        </div>
    </div>

    <script src="game.js"></script>
    <script>
        // Initialize the game
        const canvas = document.getElementById('gameCanvas');
        const gameConfig = ${JSON.stringify({ customization, parameters })};
        
        // Auto-resize canvas for mobile
        function resizeCanvas() {
            const container = document.getElementById('gameContainer');
            const maxWidth = Math.min(window.innerWidth - 20, 800);
            const maxHeight = Math.min(window.innerHeight - 20, 600);
            
            const aspectRatio = 800 / 600;
            let width = maxWidth;
            let height = width / aspectRatio;
            
            if (height > maxHeight) {
                height = maxHeight;
                width = height * aspectRatio;
            }
            
            canvas.style.width = width + 'px';
            canvas.style.height = height + 'px';
        }
        
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();
        
        // Start the game
        startGame(canvas, gameConfig);
    </script>
</body>
</html>`;
}

function generateGameJS(templateId: string, gameData: any): string {
  // This would contain the actual game engine and specific game logic
  // For now, providing a simplified version that demonstrates the structure
  
  return `
// Game Engine - Simplified Version
class GameEngine {
    constructor(canvas, config) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.config = config;
        this.isRunning = false;
        this.setupGame();
    }
    
    setupGame() {
        // Apply customization
        this.theme = this.config.customization.theme || 'default';
        this.character = this.config.customization.mainCharacter || 'default';
        
        // Apply parameters
        this.parameters = this.config.parameters || {};
        
        this.setupControls();
    }
    
    setupControls() {
        // Desktop controls
        document.addEventListener('keydown', (e) => {
            this.handleKeyPress(e.key);
        });
        
        // Mobile controls
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.handleTouch(e);
        });
        
        this.canvas.addEventListener('click', (e) => {
            this.handleClick(e);
        });
    }
    
    handleKeyPress(key) {
        switch(key) {
            case ' ':
            case 'ArrowUp':
                this.handleAction('jump');
                break;
            case 'ArrowLeft':
                this.handleAction('left');
                break;
            case 'ArrowRight':
                this.handleAction('right');
                break;
        }
    }
    
    handleTouch(e) {
        this.handleAction('jump');
    }
    
    handleClick(e) {
        this.handleAction('jump');
    }
    
    handleAction(action) {
        // Game-specific action handling would go here
        console.log('Action:', action);
    }
    
    start() {
        this.isRunning = true;
        this.gameLoop();
    }
    
    gameLoop() {
        if (!this.isRunning) return;
        
        this.update();
        this.render();
        
        requestAnimationFrame(() => this.gameLoop());
    }
    
    update() {
        // Game logic updates
    }
    
    render() {
        // Clear canvas
        this.ctx.fillStyle = this.getBackgroundColor();
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw game elements
        this.drawGame();
    }
    
    getBackgroundColor() {
        const colors = {
            'flappy-bird': '#87CEEB',
            'speed-runner': '#90EE90',
            'whack-the-mole': '#DDA0DD',
            'match3': '#4B0082',
            'crossy-road': '#90EE90'
        };
        return colors['${templateId}'] || '#87CEEB';
    }
    
    drawGame() {
        // Template-specific rendering
        this.drawTemplate${templateId.split('-').map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join('')}();
    }
    
    ${getTemplateSpecificCode(templateId)}
}

// Initialize game function
function startGame(canvas, config) {
    const game = new GameEngine(canvas, config);
    game.start();
    
    // Show instructions
    setTimeout(() => {
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = 'white';
        ctx.font = 'bold 24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('${getGameInstructions(templateId)}', canvas.width/2, canvas.height/2);
        ctx.font = '16px Arial';
        ctx.fillText('Click or tap to start!', canvas.width/2, canvas.height/2 + 40);
        
        const startGame = () => {
            canvas.removeEventListener('click', startGame);
            canvas.removeEventListener('touchstart', startGame);
            game.start();
        };
        
        canvas.addEventListener('click', startGame);
        canvas.addEventListener('touchstart', startGame);
    }, 100);
}
`;
}

function generateGameCSS(gameData: any): string {
  return `
/* Game-specific styles */
.game-ui {
    position: fixed;
    top: 20px;
    right: 20px;
    color: white;
    font-family: Arial, sans-serif;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
}

.score {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 10px;
}

.game-over {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0,0,0,0.9);
    color: white;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
    display: none;
}

.restart-btn {
    background: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 10px;
}

.restart-btn:hover {
    background: #45a049;
}

/* Mobile optimizations */
@media (max-width: 768px) {
    .game-ui {
        top: 10px;
        right: 10px;
        font-size: 18px;
    }
    
    .score {
        font-size: 20px;
    }
}
`;
}

function generateReadme(config: ExportConfig): string {
  return `${config.gameName}
Version: ${config.version}
Created by: ${config.author}

${config.description}

INSTRUCTIONS:
1. Open index.html in any modern web browser
2. The game will start automatically
3. Use keyboard controls or touch/click on mobile devices
4. Enjoy your custom-made game!

CONTROLS:
- Desktop: Use arrow keys, spacebar, or WASD
- Mobile: Tap the screen or use on-screen controls

TECHNICAL INFO:
- This game runs entirely in your browser
- No internet connection required after initial load
- Compatible with Chrome, Firefox, Safari, and Edge
- Mobile-friendly responsive design

Created with AI Game Studio
Generated on: ${new Date().toLocaleString()}
`;
}

function getBackgroundColor(customization: any): string {
  // Extract background color from AI customization or use default
  if (customization.environmentGenerated?.colors?.[0]) {
    return customization.environmentGenerated.colors[0];
  }
  return '#87CEEB';
}

function getMobileControls(templateId: string): string {
  switch (templateId) {
    case 'flappy-bird':
    case 'whack-the-mole':
      return '<button class="control-btn" onclick="game.handleAction(\'jump\')">TAP</button>';
    case 'speed-runner':
      return `
        <button class="control-btn" onclick="game.handleAction('jump')">↑</button>
        <button class="control-btn" onclick="game.handleAction('left')">←</button>
        <button class="control-btn" onclick="game.handleAction('right')">→</button>
      `;
    case 'crossy-road':
      return `
        <button class="control-btn" onclick="game.handleAction('up')">↑</button>
        <button class="control-btn" onclick="game.handleAction('down')">↓</button>
        <button class="control-btn" onclick="game.handleAction('left')">←</button>
        <button class="control-btn" onclick="game.handleAction('right')">→</button>
      `;
    default:
      return '<button class="control-btn" onclick="game.handleAction(\'action\')">PLAY</button>';
  }
}

function getGameInstructions(templateId: string): string {
  const instructions = {
    'flappy-bird': 'Tap to flap and avoid pipes!',
    'speed-runner': 'Jump over obstacles!',
    'whack-the-mole': 'Click the moles!',
    'match3': 'Match 3 or more gems!',
    'crossy-road': 'Cross safely!'
  };
  return instructions[templateId as keyof typeof instructions] || 'Play the game!';
}

function getTemplateSpecificCode(templateId: string): string {
  // Return simplified game logic for each template
  switch (templateId) {
    case 'flappy-bird':
      return `
    drawTemplateFlappyBird() {
        // Draw simplified Flappy Bird
        const ctx = this.ctx;
        
        // Draw bird
        ctx.fillStyle = '#FFD700';
        ctx.beginPath();
        ctx.arc(150, 300, 20, 0, Math.PI * 2);
        ctx.fill();
        
        // Draw pipes (simplified)
        ctx.fillStyle = '#32CD32';
        ctx.fillRect(400, 0, 50, 200);
        ctx.fillRect(400, 350, 50, 250);
    }`;
    
    case 'speed-runner':
      return `
    drawTemplateSpeedRunner() {
        const ctx = this.ctx;
        
        // Draw ground
        ctx.fillStyle = '#8B4513';
        ctx.fillRect(0, 550, this.canvas.width, 50);
        
        // Draw player
        ctx.fillStyle = '#4169E1';
        ctx.fillRect(100, 520, 30, 30);
        
        // Draw obstacle
        ctx.fillStyle = '#FF4500';
        ctx.fillRect(300, 530, 20, 20);
    }`;
    
    case 'whack-the-mole':
      return `
    drawTemplateWhackTheMole() {
        const ctx = this.ctx;
        
        // Draw holes
        ctx.fillStyle = '#8B4513';
        for (let i = 0; i < 9; i++) {
            const x = (i % 3) * 200 + 150;
            const y = Math.floor(i / 3) * 150 + 150;
            ctx.beginPath();
            ctx.arc(x, y, 40, 0, Math.PI * 2);
            ctx.fill();
        }
    }`;
    
    case 'match3':
      return `
    drawTemplateMatch3() {
        const ctx = this.ctx;
        const colors = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF'];
        
        // Draw grid
        for (let row = 0; row < 8; row++) {
            for (let col = 0; col < 8; col++) {
                const x = col * 60 + 160;
                const y = row * 60 + 60;
                const colorIndex = (row + col) % colors.length;
                
                ctx.fillStyle = colors[colorIndex];
                ctx.beginPath();
                ctx.arc(x + 30, y + 30, 25, 0, Math.PI * 2);
                ctx.fill();
            }
        }
    }`;
    
    case 'crossy-road':
      return `
    drawTemplateCrossyRoad() {
        const ctx = this.ctx;
        
        // Draw lanes
        for (let i = 0; i < 12; i++) {
            const y = i * 50;
            const isRoad = i % 2 === 0;
            ctx.fillStyle = isRoad ? '#808080' : '#0077BE';
            ctx.fillRect(0, y, this.canvas.width, 50);
        }
        
        // Draw player
        ctx.fillStyle = '#FFD700';
        ctx.fillRect(385, 575, 30, 25);
    }`;
    
    default:
      return `
    drawTemplateDefault() {
        const ctx = this.ctx;
        ctx.fillStyle = 'white';
        ctx.font = '24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Game Template', this.canvas.width/2, this.canvas.height/2);
    }`;
  }
}

// Simple ZIP creation (in production, use a proper ZIP library)
function createSimpleZip(files: Record<string, string>): string {
  // This is a very simplified ZIP-like format
  // In production, use libraries like 'archiver' or 'yauzl'
  let zipContent = 'PK\x03\x04'; // ZIP file signature
  
  for (const [filename, content] of Object.entries(files)) {
    zipContent += `\n--- FILE: ${filename} ---\n`;
    zipContent += content;
    zipContent += `\n--- END: ${filename} ---\n`;
  }
  
  return zipContent;
}
