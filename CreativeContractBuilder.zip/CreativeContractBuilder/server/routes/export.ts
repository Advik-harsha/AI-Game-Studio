import express from 'express';
import { exportGameAsZip } from '../services/gameExporter';

export const exportRoutes = express.Router();

// Export game as downloadable ZIP file
exportRoutes.post('/game', async (req, res) => {
  try {
    const { templateId, gameData, config } = req.body;

    if (!templateId || !gameData || !config) {
      return res.status(400).json({
        error: 'Missing required fields: templateId, gameData, and config are required'
      });
    }

    const zipBuffer = await exportGameAsZip(templateId, gameData, config);

    // Set headers for file download
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${config.gameName.replace(/\s+/g, '-').toLowerCase()}.zip"`);
    res.setHeader('Content-Length', zipBuffer.length);

    res.send(zipBuffer);
  } catch (error) {
    console.error('Error exporting game:', error);
    res.status(500).json({
      error: 'Failed to export game. Please try again.'
    });
  }
});
