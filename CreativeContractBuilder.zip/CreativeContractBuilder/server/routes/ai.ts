import express from 'express';
import { generateAssets, generateParameters } from '../services/openai';

export const aiRoutes = express.Router();

// Generate game assets based on AI prompts
aiRoutes.post('/generate-assets', async (req, res) => {
  try {
    const { gameTemplate, aspect, prompt } = req.body;

    if (!gameTemplate || !aspect || !prompt) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: gameTemplate, aspect, and prompt are required'
      });
    }

    const result = await generateAssets(gameTemplate, aspect, prompt);
    res.json(result);
  } catch (error) {
    console.error('Error in generate-assets:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while generating assets'
    });
  }
});

// Generate game parameters based on AI prompts
aiRoutes.post('/generate-parameters', async (req, res) => {
  try {
    const { gameTemplate, prompt, difficulty } = req.body;

    if (!gameTemplate || !prompt || !difficulty) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: gameTemplate, prompt, and difficulty are required',
        parameters: {}
      });
    }

    const result = await generateParameters(gameTemplate, prompt, difficulty);
    res.json(result);
  } catch (error) {
    console.error('Error in generate-parameters:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while generating parameters',
      parameters: {}
    });
  }
});
