import type { Express } from "express";
import { createServer, type Server } from "http";
import { aiRoutes } from "./routes/ai";
import { exportRoutes } from "./routes/export";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register AI routes
  app.use('/api/ai', aiRoutes);
  
  // Register export routes
  app.use('/api/export', exportRoutes);

  const httpServer = createServer(app);
  return httpServer;
}
